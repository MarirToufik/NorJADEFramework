package agents;
import jade.core.*;

public class ManagerAgent extends Agent{
	
	public void setup(){
		
		System.out.println("Hello!  I am the manager agent");
		this.addBehaviour(new behaviours.SupervisorBehaviour(this, 5000));

	}

}

package start;

import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.util.ExtendedProperties;
import jade.util.leap.Properties;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class Luncher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		NorJadeAspects.LoadNorJadeOntology.NorJadeOntology.getLawProperties("DangerousDrivingLaw") ;
//		NorJadeAspects.LoadNorJadeOntology.NorJadeOntology.getLawProperties("VeryDangerousDrivingLaw") ;
		try{

			String [] args1 ={"-agents"};
			Runtime rt = Runtime.instance();
			ProfileImpl p = new ProfileImpl();
		//	p.setParameter("GUI", "true");
			AgentContainer container =rt.createMainContainer(p);
			
	        agents.ManagerAgent A1 = new  agents.ManagerAgent();  
	       	AgentController AC1 = container.acceptNewAgent("Manager1", A1);
			AC1.start();
	    			}
			catch (Exception any) {
			    any.printStackTrace();
			    
			}

	}

}

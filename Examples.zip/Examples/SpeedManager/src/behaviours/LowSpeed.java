package behaviours;

import jade.core.behaviours.OneShotBehaviour;

public class LowSpeed extends OneShotBehaviour{
	
	public void action(){
		
		System.out.println("The actual speed of the car is Low Speed !");
	}

}

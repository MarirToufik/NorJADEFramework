package behaviours;

import jade.core.behaviours.OneShotBehaviour;

public class VeryHighSpeed extends OneShotBehaviour{
	
	public void action(){
		
		System.out.println("The actual speed of the car is Very High Speed !");
	}

}

package behaviours;

import jade.core.behaviours.OneShotBehaviour;

public class HighSpeed extends OneShotBehaviour{
	
	public void action(){
		
		System.out.println("The actual speed of the car is High Speed !");
	}

}

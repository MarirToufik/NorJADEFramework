package behaviours;

import jade.core.behaviours.TickerBehaviour;
import jade.core.Agent;
import java.util.Scanner;

public class SupervisorBehaviour extends TickerBehaviour {

	
	public SupervisorBehaviour(Agent a, long x){
		super(a, x);
	}

	@Override
	protected void onTick() {
		// TODO Auto-generated method stub
		System.out.println("Please choose the needed speed of the car ! ");
		System.out.println("1 : Low Speed ");
		System.out.println("2 : Appropriate Speed ");
		System.out.println("3 : High Speed ");
		System.out.println("4 : Very High Speed ");

		Scanner SC1 = new Scanner(System.in);
		int Choice = SC1.nextInt();
		
		switch(Choice){

		case 1 : {
			this.myAgent.addBehaviour(new behaviours.LowSpeed());
			break;
			
		}
		case 2 : {
			this.myAgent.addBehaviour(new behaviours.AppropriateSpeed());
			break;

		}
		case 3 : {
			this.myAgent.addBehaviour(new behaviours.HighSpeed());
			break;

		}
		case 4 : {
			this.myAgent.addBehaviour(new behaviours.VeryHighSpeed());
			break;

		}

		
		}

		
	}
}

package RewardPunishment;

import jade.core.behaviours.*;

public class FocusingCharge extends OneShotBehaviour{
	
	public void action(){
		
		System.out.println("[NorJADE Framework - Punishment] : The agent "+ this.getAgent().getLocalName() + " has to concentrate more !");
	}

}

package RewardPunishment;

import jade.core.behaviours.OneShotBehaviour;

public class ComfortableFeeling extends OneShotBehaviour{
	
	public void action(){
		
		System.out.println("[NorJADE Framework - Reward] : The agent "+ this.getAgent().getLocalName() + " feels more comfortable !");
	}

}


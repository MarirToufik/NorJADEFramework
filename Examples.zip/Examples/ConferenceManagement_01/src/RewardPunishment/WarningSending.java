package RewardPunishment;

import jade.core.behaviours.*;
import behaviours.Disappointment;
import agents.Reviewer;
import ressources.Conference;

public class WarningSending{
	
}
/*public class WarningSending extends OneShotBehaviour{
	
	public void action(){
		Conference C = ((Conference)((Reviewer)this.myAgent).CM.getListOfConferences().elementAt(0)) ;
		System.err.println("The agent : " + this.myAgent.getLocalName() + " received a punishment");
		 C.removeFromProgramCommittee(this.myAgent.getLocalName());
		System.err.println("The agent : " + this.myAgent.getLocalName() + " is removed from program committee of the Conference : " + C.getConferenceID());
		this.myAgent.addBehaviour(new Disappointment());
		
	}

}*/

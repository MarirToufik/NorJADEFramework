package RewardPunishment;

import agents.Reviewer;
import behaviours.Disappointment;
import jade.core.behaviours.OneShotBehaviour;
import ressources.Conference;

public class WarningReceived extends OneShotBehaviour{
	
	public void action(){
		Conference C = ((Conference)((Reviewer)this.myAgent).CM.getListOfConferences().elementAt(0)) ;
		System.out.println("[NorJADE Framework - Punishment] : The agent : " + this.myAgent.getLocalName() + " received a punishment");
		 C.removeFromProgramCommittee(this.myAgent.getLocalName());
		System.out.println("[NorJADE Framework - Punishment] : The agent : " + this.myAgent.getLocalName() + " is removed from program committee of the Conference : " + C.getConferenceID());
		this.myAgent.addBehaviour(new Disappointment());
		
	}

}

package behaviours;

import agents.ConferenceChair;
import ressources.Conference;
import jade.core.behaviours.*;

public class SearchReachedDeadline extends Behaviour {
	int i = 0 ;
	public void action(){
		
		if ((((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size() > 0) && (((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getDeadlineDate() < ((ConferenceChair)(this.myAgent)).CM.T.getTime()) && (!((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getDeadlineReached()
) && (((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getConferenceChair().equals(this.myAgent.getLocalName()))) {
			System.out.println("*** The agent   : "+ this.myAgent.getLocalName() + "  found  the conference" + ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getConferenceID() + "  with deadline reached");
			
			Conference C = ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i) ;
			C.setDeadlineReached(true);
		//	((ConferenceChair)(this.myAgent)).addBehaviour(new DispatchingPapers());
			this.myAgent.ReachGoal("DispatchingPaper");
			((ConferenceChair)(this.myAgent)).CM.IncreaseNbrOfReachedDeadlines();
			
		}
		
		i++ ;
		
		if (i == ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size())
			i = 0;

		
	}
	
	public boolean done(){
		return ((ConferenceChair)(this.myAgent)).CM.getNbrOfReachedDeadlines() == ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size(); 
	}

}

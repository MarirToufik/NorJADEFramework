package behaviours;

import jade.core.behaviours.Behaviour;
import agents.Author;
import ressources.Paper;

public class PaperRedaction extends Behaviour {
	Paper ThePaper ;
	PaperRedaction(){
	}
	public void setPaper(Paper ThePaper){
		this.ThePaper = ThePaper; 
	
	}
	
	public void action(){
		//	 ThePaper = ((Author)(this.myAgent)).CM.getPaperProject(((Author)(this.myAgent)).ListOfInterestedPapers.elementAt(i)) ;
		 
		 // System.out.println("*** The agent : " + this.myAgent.getLocalName() + " locked the paper : " + this.ThePaper.getPaperId());
    	         		int indexOfConributor = this.ThePaper.getContributorIndex(this.myAgent.getLocalName());
    	         		int Contribution =this.ThePaper.getContributor(indexOfConributor).getContribution();
    	         		int Productivity = ((Author)(this.myAgent)).getProductivity();
    	         		int TimeToComplet = (Contribution   * ((Author)(this.myAgent)).CM.getTimeUnit()) /  Productivity ;
    	         		/*System.out.println("*** The agent : " + this.myAgent.getLocalName() + " Contribution : " + Contribution );
    	         		System.out.println("*** The agent : " + this.myAgent.getLocalName() + " indexOfConributor : " + indexOfConributor );
    	         		System.out.println("*** The agent : " + this.myAgent.getLocalName() + " Productivity : " + Productivity );
                          
    	         		System.out.println("*** The agent : " + this.myAgent.getLocalName() + " will wait : " + TimeToComplet );*/
    	         		//this.myAgent.addBehaviour(new Behaviours.PaperRedaction(TimeToComplet));
		               // System.out.println("*** The agent   :  "+ this.myAgent.getLocalName() + "  started readaction of the paper : " + this.ThePaper.getPaperId());
    	         		this.myAgent.doWait(TimeToComplet);
    	         		//System.out.println("*** The agent : " + this.myAgent.getLocalName() + " Completed work on paper : " + ((Author)(this.myAgent)).CM.getPaperProject(((Author)(this.myAgent)).ListOfInterestedPapers.elementAt(i)).getPaperId() );
    	         		double Completeness = (Contribution * 100.0 ) / this.ThePaper.getTotalRequestedWork();
    	         		this.ThePaper.UpdateCompletenessPaper(Completeness);
    	         		//System.out.println("*** The agent : " + this.myAgent.getLocalName() + " Improve work on paper : " + this.ThePaper.getPaperId() + "  By the value  : " + Completeness);
    	         		System.out.println("*** The agent : "+this.myAgent.getLocalName() + " completed its portion of the paper : " + this.ThePaper.getPaperId()+ " ,and the current value of completeness of this paper is : " + this.ThePaper.getCompletenessPaper());
    	         		((Author)(this.myAgent)).AddListOfCompletedPapers(this.ThePaper.getPaperId());
    	         		//System.out.println("*** The agent : " + this.myAgent.getLocalName() + " add the paper : " + ((Author)(this.myAgent)).ListOfInterestedPapers.elementAt(i)+ "  To its completed list : " );
    	         		this.ThePaper.unLockPaper();	
		
		                //System.out.println("*** The agent   :  "+ this.myAgent.getLocalName() + "  started readaction of the paper : " + this.ThePaper.getPaperId());
		                //this.myAgent.doWait(RedactionTime);
		
	}
	
	public boolean done(){
		return true;
	}

}

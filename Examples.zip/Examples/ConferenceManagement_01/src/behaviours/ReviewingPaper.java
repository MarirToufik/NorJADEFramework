package behaviours;

import ressources.*;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

import java.util.Random;

import agents.*;
public class ReviewingPaper extends CyclicBehaviour {
	
     public void action(){
	     
 		MessageTemplate modele = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);	
 		MessageTemplate modele1 = MessageTemplate.MatchOntology(new String("NorJadeOntology"));
 		MessageTemplate modele2 = MessageTemplate.not(modele1);
 		MessageTemplate modele3 = MessageTemplate.and(modele, modele2);
 		ACLMessage msg = myAgent.receive(modele3);
 		  if (msg != null) {
 			  
 				  Paper P = null ;
 				 
 				try{
 				   P = (Paper)msg.getContentObject(); 
 				  
 				}catch(Exception e){
 					
 				}
 				System.out.println("***  The agent : "+ this.myAgent.getLocalName() +" received the paper " + P.getPaperId() + "  for Reviewing !" );
         		int Contribution =P.getEstimatedEvaluationWork();
         		int Productivity = ((Reviewer)(this.myAgent)).getProductivity();
         		int TimeToComplet = (Contribution   * ((Reviewer)(this.myAgent)).CM.getTimeUnit()) /  Productivity ;
 				System.out.println("***  The agent : "+ this.myAgent.getLocalName() +" will start reviweing of paper " + P.getPaperId()  );
         		this.myAgent.doWait(TimeToComplet);
 				System.out.println("***  The agent : "+ this.myAgent.getLocalName() +" restart its behaviours " );
 				Random r = new Random();
 		        int result = r.nextInt(101);
 		        ReviewingResult R = new ReviewingResult(this.myAgent.getLocalName(), P.getPaperId(), P.getConferenceID());
         		R.setEvaluation(result);
         		this.myAgent.addBehaviour(new SendEvaluationResult(R));
 		  
 		  }
 		 
 		  else {
 		    block();
 		  }

     }

}

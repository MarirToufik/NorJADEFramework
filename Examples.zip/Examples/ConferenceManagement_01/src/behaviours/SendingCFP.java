package behaviours;

import agents.ConferenceChair;
import ressources.Conference;
import jade.core.behaviours.*;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.lang.acl.*;
import java.io.*;
public class SendingCFP extends Behaviour{
	
	int i = 0 ;
	
	public void action(){
		//System.out.println("*** The agent   : "+ this.myAgent.getLocalName() + "  execute the behaviour sending CFP" );

		if ((((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size() > 0) && (((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getCFPDate() < ((ConferenceChair)(this.myAgent)).CM.T.getTime()) && (!((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getAnnounced()
) && (((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getConferenceChair().equals(this.myAgent.getLocalName()))) {
			
			System.out.println("*** The agent   : "+ this.myAgent.getLocalName() + "  found  the conference" + ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getConferenceID());
			ACLMessage message = new ACLMessage(ACLMessage.CFP);
			message.setSender(this.myAgent.getAID());
			Conference C = ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i) ;
			C.setAnnounced(true);
			try {message.setContentObject(C);
			
			}catch(IOException ie){
				ie.printStackTrace();
				
			}

			DFAgentDescription[] result = ((ConferenceChair)(this.myAgent)).getAgentDescription("CommunicatingAuthor") ;            
	        for(int i = 0; i < result.length; i ++){
	        	
	        	message.addReceiver(result[i].getName()); 
	        	
	        //	System.out.println("The first agent service is  : " + result[i].getName().getLocalName() );
	        }
	        
	        this.myAgent.send(message);
	        System.out.println("***The agent  : " + this.myAgent.getLocalName() + "  send a CFP about the conference :  " + C.getConferenceID() );
	        ((ConferenceChair)(this.myAgent)).CM.IncreaseNbrOfAnnouncedConferences();

		}
		
		i++ ;
		
		if (i == ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size())
			i = 0;
		
	}
	
	public boolean done(){
		return ((ConferenceChair)(this.myAgent)).CM.getNbrOfAnnouncedConferences() == ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size(); 
	}

}

package behaviours;

import java.io.IOException;

import agents.Reviewer;
import ressources.ReviewingResult;
import jade.core.AID;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;

public class SendEvaluationResult extends OneShotBehaviour{
	ReviewingResult Result ;
	public SendEvaluationResult(ReviewingResult Result){
		this.Result = Result ;
	}
	public void action (){
		ACLMessage message = new ACLMessage();

		if (Result.getEvaluation() > 49) 
			message.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
		else
			message.setPerformative(ACLMessage.REJECT_PROPOSAL);
		
		
			message.setSender(this.myAgent.getAID());
		try {message.setContentObject(this.Result);
		
		}catch(IOException ie){
			ie.printStackTrace();
			
		}
		
		String S = ((Reviewer)(this.myAgent)).CM.getConference(Result.getConferenceId()).getConferenceChair() ;
		
		message.addReceiver(new AID(S, AID.ISLOCALNAME));
		myAgent.send(message);
		
		System.out.println("*** The agent " + myAgent.getLocalName() + " send its evaluation of the paper " + Result.getPaperId()+ " to the chair  : " + S);
	}

}

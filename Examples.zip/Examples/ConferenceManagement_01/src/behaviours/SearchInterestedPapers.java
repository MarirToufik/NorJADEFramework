package behaviours;

import jade.core.behaviours.*;
import agents.Author;
import agents.CommunicatingAuthor;

public class SearchInterestedPapers extends Behaviour{
	int i = 0 ;
	//int j = 0;
	

	public void action(){
		String S = new String(this.myAgent.getLocalName());
		//System.out.println("*** The agent : " + S + " started the behavior SearchInterestedPapers");
		
		if ( (((Author)(this.myAgent)).CM.getPapersProjects().size() > 0 ) && ( ((Author)(this.myAgent)).CM.getPapersProjects().elementAt(i).getContributorIndex(S) != -1)){
		//	System.out.println("*** The agent : " + S + " found an interested paper un papier");
			((Author)(this.myAgent)).AddListOfInterestedPapers(((Author)(this.myAgent)).CM.getPapersProjects().elementAt(i).getPaperId());
		}	

		i++; 
		//j++ ;
		
		if (i == ((Author)(this.myAgent)).CM.getPapersProjects().size()) 
			i = 0;
		
				
	}
	public boolean done(){
	   	 return ((Author)(this.myAgent)).CM.getNbrOfFinishedPapers() == ((Author)(this.myAgent)).CM.getPapersProjects().size();
		//  return j == 2000 ;
		//return 		((Author)(this.myAgent)).CM.getPapersProjects().size() == 0 ;

	}

}

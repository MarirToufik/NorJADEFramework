package behaviours;

import agents.*;
import ressources.*;
import jade.core.behaviours.*;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.lang.acl.*;
import java.io.*;


public class ReceivingCFP extends Behaviour{
	
	public void action(){
		MessageTemplate modele = MessageTemplate.MatchPerformative(ACLMessage.CFP);			 
		ACLMessage msg = myAgent.receive(modele);
		  if (msg != null) {
		    // process the message
			  
			 // if (msg.getPerformative() == ACLMessage.CFP ){
				  Conference C = null ;
				 
				try{
				   C = (Conference)msg.getContentObject(); 
				  
				}catch(Exception e){
					
				}
				System.out.println("***  The agent : "+ this.myAgent.getLocalName() +" received the CFP of the conference " + C.getConferenceID() );
				((CommunicatingAuthor)(this.myAgent)).AddListOfReceivedCFP(C.getConferenceID());
			  }
		 // }
		  else {
		    block();
		  }
	
	}
	
	public boolean done(){
		return ((CommunicatingAuthor)(this.myAgent)).ListOfReceivedCFP.size() == ((CommunicatingAuthor)(this.myAgent)).CM.getListOfConferences().size();
	}

}

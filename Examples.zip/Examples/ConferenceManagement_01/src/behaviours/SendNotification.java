package behaviours;

import java.io.IOException;

import agents.ConferenceChair;
import ressources.*;
import jade.core.AID;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
public class SendNotification extends OneShotBehaviour{
	private Conference TheConference ;
/*	public SendNotification(Conference TheConference){
		this.TheConference = TheConference ;	
	}*/
	
	public SendNotification(){
		this.TheConference = (Conference)((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(0);
	
	}

	public void action(){
		
		System.out.println("*** The agent  :  " + this.myAgent.getLocalName() + "  will send the notification of the conference " + this.TheConference.getConferenceID());

		
		for (int i =0 ; i < this.TheConference.getReceivedPaper().size(); i ++){
			ACLMessage message = new ACLMessage();
			//this.TheConference.getReceivedPaper().elementAt(i).DisplayReviewingResults();
			double FinalResult = this.TheConference.getReceivedPaper().elementAt(i).CalculateFinalDeision() ;
			if (FinalResult > 49.9){ 
			   message.setPerformative(ACLMessage.ACCEPT_PROPOSAL);	
			   this.TheConference.getReceivedPaper().elementAt(i).setConferenceChairdecision(1);
			}
			
			else{
			   message.setPerformative(ACLMessage.REJECT_PROPOSAL);
			   this.TheConference.getReceivedPaper().elementAt(i).setConferenceChairdecision(-1);

			}
			
			try {
				message.setContentObject(this.TheConference.getReceivedPaper().elementAt(i));
			}catch(IOException ie){
				ie.printStackTrace();
				
			}
			
			message.addReceiver(new AID(this.TheConference.getReceivedPaper().elementAt(i).getCommunicatingAuthor(), AID.ISLOCALNAME));
				
			this.myAgent.send(message);
			
			System.out.println("*** The agent  :  " + this.myAgent.getLocalName() + "  send the decision " + this.TheConference.getReceivedPaper().elementAt(i).getFinalDeision() + " as a final decision to the agent  : " + this.TheConference.getReceivedPaper().elementAt(i).getCommunicatingAuthor());
		}
		
	}

}

package agents;

import jade.core.*;
import jade.core.behaviours.*;
import start.ConferenceManagment;
import java.util.Vector;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.*;
import jade.domain.FIPAException;

public class Author extends Agent{
	
	private int productivity ;
	final private int MaxProductivity = 100 ;
	final private int MinProductivity = 5 ;
	static public ConferenceManagment CM ;
	
	public Vector <Integer> ListOfInterestedPapers = new Vector(); 
	public Vector <Integer> ListOfCompletedPapers = new Vector(); 

	
	
	
	
	public Author (ConferenceManagment CM, int productivity){
		//System.out.println("Je suis le constructeur de  author ");
		this.productivity = productivity ;
        this.CM = CM;
        
	}
	
	public void setup(){
		
		// Regustration in DF
		
	    DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName( this.getAID() );
        
        ServiceDescription sd  = new ServiceDescription();
        sd.setType( "Author" );
        sd.setName( this.getLocalName() );
        dfd.addServices(sd);
        
        try {  
            DFService.register(this, dfd );  
        }
        catch (FIPAException fe) { 
        	fe.printStackTrace(); }

		this.ReachGoal("DispatchingPaper");
		this.doWait(2000);
		this.addBehaviour(new behaviours.SearchInterestedPapers());
		this.addBehaviour(new behaviours.WritingPaper());	
        this.addBehaviour(new behaviours.ReceivingNotificationbyAuthors());
		}

	
	public void setProductivity(int x){
		this.productivity = x;
	}
	
	public int getProductivity(){
		return this.productivity;
	}
	
	public void IncreaseProductivity(int x){
		if (this.productivity+x <= this.MaxProductivity) 
			this.productivity = this.productivity+x;
		else 
			this.productivity = this.MaxProductivity ; 
	}
	
	public void DecreaseProductivity(int x){
		if (this.productivity-x > this.MinProductivity) 
			this.productivity = this.productivity-x;
		else 
			this.productivity = this.MinProductivity ; 
	}
	
	public void IncreasingProductivity(){
		System.out.println("The agent : " + this.getLocalName() + "  will increase its productivity");

		if (this.productivity+5 <= this.MaxProductivity) 
			this.productivity = this.productivity+5;
		else 
			this.productivity = this.MaxProductivity ;
	}
	
	public void DecreasingProductivity(){
		System.out.println("The agent : " + this.getLocalName() + "  will decrease its productivity");

		if (this.productivity-5 > this.MinProductivity) 
			this.productivity = this.productivity-5;
		else 
			this.productivity = this.MinProductivity ;
	}
	
	public void AddListOfInterestedPapers(int PaperId){
		if (! this.ListOfInterestedPapers.contains(new Integer(PaperId))) { 
			this.ListOfInterestedPapers.addElement(new Integer(PaperId));
			System.out.println("*** The Paper  :  " + PaperId + "   is added to InterestedPapers of the agent :  " + this.getLocalName());
		}
		else
			;
		//	System.out.println("*** The Paper  :  " + PaperId + "  is already exist");
	}
	
	public void AddListOfCompletedPapers(int PaperId){
		if (! this.ListOfCompletedPapers.contains(new Integer(PaperId))) { 
			this.ListOfCompletedPapers.addElement(new Integer(PaperId));
			System.out.println("*** The Paper  :  " + PaperId + "   is added to ListOfCompletedPapers of the agent :  " + this.getLocalName());
		}
		else
			;
			//System.out.println("*** The Paper  :  " + PaperId + "  is already exist in ListOfCompletedPapers");
	}
	


}

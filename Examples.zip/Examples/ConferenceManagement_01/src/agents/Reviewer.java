package agents;

import start.ConferenceManagment;
import jade.core.*;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.*;
import jade.domain.FIPAException;
import behaviours.*;

public class Reviewer extends Agent {
	
	private int productivity ;
	final private int MaxProductivity = 100 ;
	final private int MinProductivity = 5 ;
	public static  ConferenceManagment CM ;
	public Reviewer(ConferenceManagment CM, int productivity){
		
		this.CM = CM ;
		this.productivity = productivity ;
	}

	public void setup(){		
	    DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName( this.getAID() );
        
        ServiceDescription sd  = new ServiceDescription();
        sd.setType( "Reviewer" );
        sd.setName( this.getLocalName() );
        dfd.addServices(sd);
        
        try {  
            DFService.register(this, dfd );  
        }
        catch (FIPAException fe) { 
        	fe.printStackTrace(); }
        this.addBehaviour(new ReviewingPaper());
        this.addBehaviour(new RewardPunishment.ReceivingPunishment());

		
	}
	
	public void setProductivity(int x){
		this.productivity = x;
	}
	
	public int getProductivity(){
		return this.productivity;
	}
	
	public void IncreasingProductivity(int x){
		if (this.productivity+x <= this.MaxProductivity) 
			this.productivity = this.productivity+x;
		else 
			this.productivity = this.MaxProductivity ; 
	}
	
	public void DecreasingProductivity(int x){
		if (this.productivity-x > this.MinProductivity) 
			this.productivity = this.productivity-x;
		else 
			this.productivity = this.MinProductivity ; 
	}
	
	public void IncreasingProductivity(){
		System.out.println("The agent : " + this.getLocalName() + "  will increase its productivity");
		if (this.productivity+5 <= this.MaxProductivity) 
			this.productivity = this.productivity+5;
		else 
			this.productivity = this.MaxProductivity ;
	}
	
	public void DecreasingProductivity(){
		System.out.println("The agent : " + this.getLocalName() + "  will decrease its productivity");
		if (this.productivity-5 > this.MinProductivity) 
			this.productivity = this.productivity-5;
		else 
			this.productivity = this.MinProductivity ;
	}

}

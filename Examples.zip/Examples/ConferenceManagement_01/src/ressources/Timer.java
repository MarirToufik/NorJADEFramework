package ressources;

public class Timer extends Thread{
	
	private static int TimeIs;
	private int Period ;
	
	
	public Timer(int Period){
		this.TimeIs = 0 ;
		this.Period = Period ;
	}
	
	public int getTime(){
		return this.TimeIs;
	}
	
	public int getPeriod(){
		return this.Period;
	}
	
	public void setPeriod(int Period){
		this.Period = Period;
	}
	public void run()  {	
	  while (true){
        
	     try{
	       this.sleep(this.Period);}
        catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

        this.TimeIs ++ ;
       
	  }
	  
}

	

}

package ressources;

import java.io.Serializable;

public class ReviewingResult  implements Serializable{
	
	private String Reviewer ; 
	private int PaperId ;
	private int ConferenceId;
	private int Evaluation ;
	
	public ReviewingResult(String Reviewer, int PaperId, int ConferenceId){
		this.Reviewer = Reviewer ;
		this.PaperId = PaperId; 
		this.ConferenceId = ConferenceId ;
		this.Evaluation = -1 ;
	}
	
	public String getReviewer(){
		return this.Reviewer ;
	}

	public void setReviewer(String S){
		 this.Reviewer = S;
	}
	
	public int getPaperId(){
		return this.PaperId ;
	}

	public void setPaperId(int S){
		 this.PaperId = S;
	}
	
	public int getConferenceId(){
		return this.ConferenceId ;
	}

	public void setConferenceId(int S){
		 this.ConferenceId = S;
	}

	public int getEvaluation(){
		return this.Evaluation ;
	}

	public void setEvaluation(int S){
		 this.Evaluation = S;
	}


}

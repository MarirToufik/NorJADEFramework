package NorJadeOntology;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Add_request {
	NorJadeOntologyBase base;
	public Add_request(String base_name){
		base = new NorJadeOntologyBase(base_name);
	}
	/* return true if the individual exist in the ontology else false*/
	boolean Is_Individual_exist(String Indiv){
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
				+ "SELECT ?type {"
				+ "Base:"+Indiv+" rdf:type ?type . }";
		try{
			Indiv = base.QueryExecuting(Query, 1, 0)[0];
			return true;
		}catch(Exception e){
			return false;
		}
	}
	/*insert new law with all attribute 
	 * parameter of this function is the law and an array contain all attribute of the law as follow :
	 * 0: The Enforcer / 1: The Norm /2: The Behavior /3:The Regulation Mechanism
	 * 4: The consequence /5: Law Id /6: Validity /7:Deontic operator 
	 */
	public void Insert_Law(String Law ,String LawProperties[]) {
		boolean All_exist = true;
		String Property = null;
		for(int i = 0; i<LawProperties.length;i++){
			if(i!=5)All_exist = Is_Individual_exist(LawProperties[i]);
			if(!All_exist){
				switch(i){
				case 0: Property = "The Enforcer"; break;
				case 1: Property = "The Norm"; break;
				case 2: Property = "The Behavior"; break;
				case 3: Property = "The Regulation Mechanism"; break;
				case 4: Property = "The consequence "; break;
				case 6: Property = "The Validity"; break;
				case 7: Property = "The Deontic operator"; break;
				}
				i= LawProperties.length;
			}
		}
		if(!All_exist){
			JOptionPane.showMessageDialog(new JFrame(), Property + " does not existe in the ontology");
		}else{
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + Law+ " a Base:Law ." 
				+ " Base:" + Law + " Base:AppliedBy Base:"+LawProperties[0]+" ."
				+ " Base:" + LawProperties[1] + " Base:ComposedOf Base:"+Law+" ."
				+ " Base:" + Law + " Base:Control Base:"+LawProperties[2]+" ."
				+ " Base:" + Law + " Base:ImplementedBy Base:"+LawProperties[3]+" ."
				+ " Base:" + Law + " Base:RewardedPunishedBy Base:"+LawProperties[4]+" ."
				+ " Base:" + Law + " Base:LawId "+LawProperties[5]+" ."
				+ " Base:" + Law + " Base:ValidDuring Base:"+LawProperties[6]+" ." 
				+ " Base:" + Law + " Base:SpecifiedBy Base:"+LawProperties[7]+" ."
			    + "}";
		base.UpdateExecuting(Query);
		}
	}
	/*insert new Behavior with all attribute 
	 * parameter of this function is the Behavior and an array contain all attribute of the Behavior as follow :
	 * 0: The Agent / 1: The Behavior Name 
	 */
	public void Insert_Behavior(String Behavior ,String BehaviorProperties[]) {
		if(!Is_Individual_exist(BehaviorProperties[0])){
			JOptionPane.showMessageDialog(new JFrame(), "The Agent does not existe in the ontology");
		}else{
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + Behavior+ " a Base:Behaviour ." 
				+ " Base:" + Behavior + " Base:BehaviourExecutedBy Base:"+BehaviorProperties[0]+" ."
				+ " Base:" + Behavior + " Base:BehaviourName '"+BehaviorProperties[1]+"' ."
				+ "}";
		base.UpdateExecuting(Query);
		}
	}
	/*insert new Agent to the Ontology 
	 * parameter of this function is the agent and the type of agent :
	 * if the Agent is a specific agent : put agent name in the parameter and null in the agent class
	 * if the agent is belong to a class : put the class in the parameter and null in the agent name
	 * else : put null in the agent class and agent name
	 */
	public void Insert_Agent(String Agent ,String Agent_Class,String Agent_Name) {
		String Query;
		if(Agent_Class == null && Agent_Name == null){
			Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
					+ "INSERT DATA {" 
					+ " Base:" + Agent + " a Base:AnyAgent . }";
		}else if (Agent_Class != null){
			Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
					+ "INSERT DATA {" 
					+ " Base:" + Agent + " a Base:ClassOfAgent . "
					+ " Base:" + Agent + " Base:AgentClass '"+ Agent_Class+"' . }";
		}else {
			Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
					+ "INSERT DATA {" 
					+ " Base:" + Agent + " a Base:SpecificAgent . "
					+ " Base:" + Agent + " Base:AgentName '"+ Agent_Name+"' . }";
		}
		base.UpdateExecuting(Query);
	}
	/*insert new Consequence with all attribute 
	 * parameter of this function is the Consequence and an the type of the Consequence (method or behavior)
	 */
	public void Insert_Consequence(String Consequence ,String Consequence_type) {
		if(!Is_Individual_exist(Consequence_type)){
			JOptionPane.showMessageDialog(new JFrame(), "the type of the consequence does not existe in the ontology");
		}else{
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + Consequence+ " a Base:Consequence ." 
				+ " Base:" + Consequence + " Base:CanBe Base:"+Consequence_type+" ."
				+ "}";
		base.UpdateExecuting(Query);
		}
	}
	/*insert new Constitution Mechanism to the Ontology 
	 * parameter of this function is the Constitution Mechanism and the type of Constitution Mechanism :
	 * if the Constitution Mechanism is a Social Power : put Realized by in the parameter and null in the according to
	 * if the Constitution Mechanism is a Voting  : put according to in the parameter and null in the realized by
	 */
	public void Insert_Constituation_Mechanism(String ConstituationMechanism ,String Realized_by,String According_to,String Norm) {
		String Query;
		if(Is_Individual_exist(According_to) || Is_Individual_exist(Realized_by)){
		if (Realized_by != null){
			Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
					+ "INSERT DATA {" 
					+ " Base:" + ConstituationMechanism + " a Base:SocialPower . "
					+ " Base:" + ConstituationMechanism + " Base:RealizedBy Base:"+ Realized_by+" "
					+ " Base:" + Norm +" Base:Use Base:"+ ConstituationMechanism +" . "
							+ "}";
		}else {
			Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
					+ "INSERT DATA {" 
					+ " Base:" + ConstituationMechanism + " a Base:Voting . "
					+ " Base:" + ConstituationMechanism + " Base:AccordingTo Base:"+ According_to+" "
					+ " Base:" + Norm +" Base:Use Base:"+ ConstituationMechanism +" . "
							+ "}";
		}
		base.UpdateExecuting(Query);
		}else{
			JOptionPane.showMessageDialog(new JFrame(), "One of the property does not exist in the ontology");
		}
	}
	/*insert new Enforcer with all attribute 
	 * parameter of this function is the Enforcer and an the Name of the Enforcer
	 */
	public void Insert_Enforcer(String Enforcer ,String Enforcer_Name) {
		if(!Is_Individual_exist(Enforcer_Name)){
			JOptionPane.showMessageDialog(new JFrame(), "the Agent does not existe in the ontology");
		}else{
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + Enforcer + " a Base:ThirdPartyEnforcer ." 
				+ " Base:" + Enforcer + " Base:EnforcerNameIs Base:"+Enforcer_Name+" ."
				+ "}";
		base.UpdateExecuting(Query);
		}
	}
	/*insert new Enforcer with all attribute 
	 * parameter of this function is the Event, The type of the Event (start or end) 
	 * and an array contain all attribute of the event as follow:
	 * 0: The Agent who trigger the Event /1: The Type of Event /2: Method executed
	 * 3: Performative of the message /4: the receiver of message /5: the sender of message
	 * 6: The Variable of the Event /7: the event important to who 
	 */
	public void Insert_Event(String Event ,String Event_type, String EventProperties[]) {
		if(!Is_Individual_exist(EventProperties[0]) || !Is_Individual_exist(EventProperties[7])){
			JOptionPane.showMessageDialog(new JFrame(), "One of the property does not existe in the ontology");
		}else{
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + Event + " a Base:"+Event_type+" ." 
				+ " Base:" + Event + " Base:TriggeredBy Base:"+EventProperties[0]+" ."
				+ " Base:" + Event + " Base:EventType '"+EventProperties[1]+"' ."
				+ " Base:" + Event + " Base:MethodExecuted '"+EventProperties[2]+"' ."
				+ " Base:" + Event + " Base:Performative '"+EventProperties[3]+"' ."
				+ " Base:" + Event + " Base:Receiver '"+EventProperties[4]+"' ."
				+ " Base:" + Event + " Base:Sender '"+EventProperties[5]+"' ."
				+ " Base:" + Event + " Base:VariableName '"+EventProperties[6]+"' ."
				+ " Base:" + Event + " Base:ImportantFor Base:"+EventProperties[7]+" ."
				+ "}";
		base.UpdateExecuting(Query);
		}
	}
	/*insert new Goal to the Ontology 
	 * parameter of this function is the Goal, Goal Name and the type of Goal :
	 * if the Goal is a Collective Goal : put RequireParticipationIn in the parameter and null in the ReachedBy
	 * if the Goal is a Individual Goal : put ReachedBy in the parameter and null in the RequireParticipationIn
	 */
public  void Insert_Goal(String Goal ,String RequireParticipationIn,String ReachedBy, String GoalName, String Norm) {
		String Query;
		if(Is_Individual_exist(ReachedBy) || Is_Individual_exist(RequireParticipationIn)){
		if (RequireParticipationIn != null){
			Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
					+ "INSERT DATA {" 
					+ " Base:" + Goal + " a Base:CollectiveGoal . "
					+ " Base:" + Goal + " Base:RequireParticipationIn Base:"+ RequireParticipationIn+" . "
					+ " Base:" + Goal + " Base:GoalName '"+ GoalName +"'."
					+ " Base:" + Norm + " Base:DefinedBy Base:"+ Goal +" ."
					+ "}";
		}else {
			Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
					+ "INSERT DATA {" 
					+ " Base:" + Goal + " a Base:IndividualGoal . "
					+ " Base:" + Goal + " Base:ReachedBy Base:"+ ReachedBy+" . "
					+ " Base:" + Goal + " Base:GoalName '"+ GoalName +"' ."
					+ " Base:" + Norm + " Base:DefinedBy Base:"+ Goal +" ."
							+ "}" ;
		}
		base.UpdateExecuting(Query);
		}else{
			JOptionPane.showMessageDialog(new JFrame(), "One of the property does not exist in the ontology");
		}
	}
	/*insert new Enforcer with all attribute 
	 * parameter of this function is the Limit, and the End Event or scope
	 */
public void Insert_Limit(String Limit ,String LimitationSpecifiedBy) {
		if(!Is_Individual_exist(LimitationSpecifiedBy)){
			JOptionPane.showMessageDialog(new JFrame(), "the End Event or the scope does not existe in the ontology");
		}else{
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + Limit + " a Base:SpecifiedLimit ." 
				+ " Base:" + Limit + " Base:TriggeredBy Base:"+LimitationSpecifiedBy+" ."			
				+ "}";
		base.UpdateExecuting(Query);
		}
	}
	/*insert new Method to the ontology
	 * parameter of this function is the method, and the Method name
	 */
public void Insert_Method(String Method ,String Method_Name) {
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + Method + " a Base:Method ." 
				+ " Base:" + Method + " Base:MethodName '"+Method_Name+"' ."			
				+ "}";
		base.UpdateExecuting(Query);
		
	}
	/*insert new Norm to the Ontology 
	 * parameter of this function is the Norm, The type of the Norm (AddingLaw,SuppressingLaw,UpdatingLaw,ProceduralNorm or RegulativeNorm) 
	 * add only the norm and when the law is created we create the relation between them
	 */
public void Insert_Norm(String Norm ,String Norm_type) {
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + Norm + " a Base:"+Norm_type+" .}" ;
		base.UpdateExecuting(Query);
		
	}
	/*insert new Protocol to the Ontology 
	 * parameter of this function is the Protocol and the Protocol Id
	 */
public void Insert_Protocol(String Protocol ,String ProtocolId) {
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + Protocol + " a Base:Protocol ." 
				+ " Base:" + Protocol + " Base:ProtocolId '"+ProtocolId+"' ."
				+ "}";
		base.UpdateExecuting(Query);
		
	}
	/*insert new Regulation Mechanism to the Ontology 
	 * parameter of this function is the Regulation Mechanism and the Agent who applies the law
	 */
public void Insert_Regulation_Mechanism(String RegulationMechanism ,String ExecutedBy) {
		if(Is_Individual_exist(ExecutedBy)){
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + RegulationMechanism + " a Base:Enforcement ." 
				+ " Base:" + RegulationMechanism + " Base:ExecutedBy Base:"+ExecutedBy+" ."
				+ "}";
		base.UpdateExecuting(Query);
		}else{
			JOptionPane.showMessageDialog(new JFrame(), "the Agent does not exist in the ontology");
		}
		
	}
	/*insert new Scope to the Ontology 
	 * parameter of this function is the Scope and the time of the scope
	 */
public void Insert_Scope(String Scope ,String Time) {
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + Scope + " a Base:Scope ." 
				+ " Base:" + Scope + " Base:Time '"+Time+"' ."
				+ "}";
		base.UpdateExecuting(Query);
		
	}
	/*insert new Time Duration to the Ontology 
	 * parameter of this function is the Time Duration, the limitation and the start
	 */
public void Insert_Time_Duration(String TimeDuration ,String LimitedBy, String StartedBy) {
		if(Is_Individual_exist(StartedBy) && Is_Individual_exist(LimitedBy)){
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "INSERT DATA {" 
				+ " Base:" + TimeDuration + " a Base:LimitedDuration ." 
				+ " Base:" + TimeDuration + " Base:LimitedBy Base:"+LimitedBy+" ."
				+ " Base:" + TimeDuration + " Base:StartedBy Base:"+StartedBy+" ."
				+ "}";
		base.UpdateExecuting(Query);
		}else{
			JOptionPane.showMessageDialog(new JFrame(), "One of the property does not exist in the ontology");
		}
		
	}
	/*insert new VAlidity to the Ontology 
	 * parameter of this function is the Validity and the type of Validity :
	 * if the Validity has a Time Duration : put Hold During in the parameter and null in the TestedBy
	 * if the Validity has a Conditional Test : put TestedBy in the parameter and null in the HoldDuring
	 */
public void Insert_Validity(String Validity ,String HoldDuring,String TestedBy) {
		String Query;
		if(Is_Individual_exist(TestedBy) || Is_Individual_exist(HoldDuring)){
		if (HoldDuring != null){
			Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
					+ "INSERT DATA {" 
					+ " Base:" + Validity + " a Base:Validity . "
					+ " Base:" + Validity + " Base:HoldDuring Base:"+ HoldDuring +" . "
					+ "}";
		}else {
			Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
					+ "INSERT DATA {" 
					+ " Base:" + Validity + " a Base:Validity . "
					+ " Base:" + Validity + " Base:ReachedBy Base:"+ TestedBy +" . "
					+ "}";
		}
		base.UpdateExecuting(Query);
		}else{
			JOptionPane.showMessageDialog(new JFrame(), "One of the property does not exist in the ontology");
		}
	}
}

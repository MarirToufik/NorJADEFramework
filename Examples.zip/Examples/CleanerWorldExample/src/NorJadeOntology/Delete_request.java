package NorJadeOntology;



import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class Delete_request {
	NorJadeOntologyBase base;
	public Delete_request(String base_name){
		base = new NorJadeOntologyBase(base_name);
	}
	/* remove law from the ontology
	 * if the user know the law he want to remove just put it in law parameter and LawId -1 
	 * else the parameter law null and put the id of law in the LawId 
	 */
	public void Delete_Law(int LawId, String Law_Indiv){
		String Query;
		if(Law_Indiv == null){
		Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "SELECT ?Law "
				+ "WHERE {"
				+ "?Law Base:LawId "+LawId+" ." 
				+ "}";
		try{
			Law_Indiv = base.QueryExecuting(Query, 1, 0)[0];
			}catch(NullPointerException e){
				JOptionPane.showMessageDialog(new JFrame(), "The Law does not exist in the ontology");
			}
		}
		Simple_Delete(Law_Indiv);
	}
	/* remove Behavior from the ontology
	 * if the user know the Behavior he want to remove just put it in Behavior parameter and Behavior name empty 
	 * else the parameter Behavior null and put the name of behavior in the behavior_name
	 */
	public void Delete_Behavior(String Behavior_name, String Behavior_Indiv){
		String Query;
		if(Behavior_Indiv == null){
			Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
					+ "SELECT ?Behavior "
					+ "WHERE {"
					+ "?Behavior  Base:BehaviourName '"+Behavior_name+"' ." 
					+ "}";
			try{
			Behavior_Indiv = base.QueryExecuting(Query, 1, 0)[0];
			}catch(NullPointerException e){
				JOptionPane.showMessageDialog(new JFrame(), "The Behavior does not exist in the ontology");
			}
		}
		Simple_Delete(Behavior_Indiv);
	}
	/* remove Enforcer from the ontology
	 * if the user know the Enforcer he want to remove just put it in Enforcer parameter and Enforcer name empty 
	 * else the parameter Enforcer null and put the name of Enforcer in the Enforcer_name
	 */
	public void Delete_Enforcer(String Enforcer_name, String Enforcer_Indiv){
		String Query;
		if(Enforcer_Indiv == null){
			Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
					+ "SELECT ?Enforcer "
					+ "WHERE {"
					+ "?Enforcer Base:EnforcerNameIs Base:"+Enforcer_name+" ." 
					+ "}";
			Enforcer_Indiv = base.QueryExecuting(Query, 1, 0)[0];
		}
		Simple_Delete(Enforcer_Indiv);
	}
	/* remove an individual from the ontology (any class)*/
	public void Simple_Delete(String Indiv){
		String Query = "PREFIX Base:<http://www.semanticweb.org/acer/ontologies/2018/4/untitled-ontology-5#>"
				+ "DELETE where{Base:"+Indiv+" ?p ?o }";
		base.UpdateExecuting(Query);
		
	}
}

package start;

import jade.core.AgentState;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.util.ExtendedProperties;
import jade.util.leap.Properties;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class Luncher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 agents.Environment MyEnvironment = new agents.Environment();
 MyEnvironment.Initialization();
 MyEnvironment.DisplayGarbagePosition();
		try{

			String [] args1 ={"-agents"};
			Runtime rt = Runtime.instance();
			ProfileImpl p = new ProfileImpl();
		//	p.setParameter("GUI", "true");
			AgentContainer container =rt.createMainContainer(p);
			
	       // agents.CleanerRobot A1 = new  agents.CleanerRobot();
	       //	AgentController AC1 = container.acceptNewAgent("Robot", A1);

	        agents.SupervisorAgent A2 = new agents.SupervisorAgent();
	       	AgentController AC2 = container.acceptNewAgent("Supervisor", A2);

			AC2.start();
	    			}
			catch (Exception any) {
			    any.printStackTrace();
			    
			}

	}

}

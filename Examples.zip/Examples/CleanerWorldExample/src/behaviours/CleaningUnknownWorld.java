package behaviours;

import jade.core.behaviours.*;

public class CleaningUnknownWorld extends Behaviour{
	agents.Environment TheEnvironment = new agents.Environment() ;
	int ActualPositionX = 0 ; 
	int ActualPositionY = 0 ; 
	int ExploredPosition = 0 ;
	int Direction = 1 ; 

	public void action(){
		System.out.println("This is the cleaner behaviour and I am in the position : " + ActualPositionX + " ; " + ActualPositionY);
		if(TheEnvironment.Env[ActualPositionX][ActualPositionY] == 1){
			TheEnvironment.Env[ActualPositionX][ActualPositionY] = 0;
			System.out.println("A garbage is founed in the position : " + ActualPositionX + " ; " + ActualPositionY + " ,  and it is removed !");
		}
		if(((ActualPositionX == 0) && (Direction == -1)) || ((ActualPositionX == (TheEnvironment.LengthX - 1)) && (Direction == 1 )) ){
			Direction = Direction * -1 ;
			ActualPositionY++ ;
		}
		else{
			ActualPositionX = ActualPositionX + Direction ;
		}
		
		ExploredPosition++ ;
	}
	
	public boolean done(){
		return ((TheEnvironment.LengthX * TheEnvironment.LengthY) == ExploredPosition) ;
	}
	
	public int onEnd(){
		this.myAgent.doDelete();
		return 0; 
	}


}

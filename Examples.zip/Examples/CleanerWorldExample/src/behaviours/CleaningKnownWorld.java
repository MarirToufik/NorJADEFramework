package behaviours;
import jade.core.behaviours.*;

public class CleaningKnownWorld extends Behaviour{
	
	agents.Environment TheEnvironment = new agents.Environment() ;
	int ActualPositionX = 0 ; 
	int ActualPositionY = 0 ; 
    int getNextPosition(int x, int y, agents.Environment Env){
    	int BestPosition = 0 ;
    	double BestDistance = -1.0 ;
    	for(int i = 0; i < Env.GarbagePosition.size(); i++){
    		double Distance = Math.sqrt(Math.pow(x - Env.GarbagePosition.elementAt(i).x, 2) + Math.pow(y - Env.GarbagePosition.elementAt(i).y, 2) );
    	    if((BestDistance == -1.0) || (Distance < BestDistance )) {
    	    	BestDistance = Distance ;
    	    	BestPosition = i ;
    	    }
    	}
    	
    	return BestPosition;
    }
	public void action(){
		
		System.out.println("This is the cleaner behaviour and I am in the position : " + ActualPositionX + " ; " + ActualPositionY);
		if(TheEnvironment.GarbagePosition.size() > 0){
			int j = getNextPosition(ActualPositionX, ActualPositionY, TheEnvironment) ;
			ActualPositionX = TheEnvironment.GarbagePosition.elementAt(j).x ;
			ActualPositionY = TheEnvironment.GarbagePosition.elementAt(j).y ;
			System.out.println("A garbage is founed in the position : " + ActualPositionX + " ; " + ActualPositionY + " ,  and it is removed !");
			TheEnvironment.GarbagePosition.remove(j);
			
		}	
	}

	public boolean done(){
		
		return TheEnvironment.GarbagePosition.size() == 0; 
	}
	public int onEnd(){
		this.myAgent.doDelete();
		return 0; 
	}
}

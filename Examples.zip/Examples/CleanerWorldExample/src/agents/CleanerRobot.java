package agents;

import java.util.Scanner;

import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import NorJadeOntology.*;

public class CleanerRobot extends Agent {
	
	public void setup(){
		System.out.println("Hello ! I am the cleaner robot !");
	    this.ReachGoal("CleaningWorld");
	}

}

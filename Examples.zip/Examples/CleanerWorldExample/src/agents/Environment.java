package agents;
import java.util.*;

import jade.core.Agent;
public class Environment {
	static public int  LengthX = 5 , LengthY = 5;
	static public int Env [] [] = new  int[LengthX] [LengthY] ; 
	static public Vector <Position>  GarbagePosition = new  Vector <Position> () ;
	

	
	static public class Position{
		public int x , y ; 
		public Position(int x, int y){
			this.x = x ; 
			this.y = y ;
		}
	}

	static public void Initialization(){
		for (int i = 0 ; i < Environment.LengthX ; i ++) 
			for (int j = 0 ; j < Environment.LengthY; j ++) 
			{
			if (Math.random() >  0.75) {
				Environment.Env[i][j]= 1; 
				Position P = new Position(i, j);
				GarbagePosition.addElement(P);
				System.out.println("there is a garbage in the position : " + i + " ; " + j);
			}else{
				Environment.Env[i][j]= 0; 

			}
				
			}
	}
	
	static public void DisplayGarbagePosition(){
		System.out.println("Garbages are positioned in : " );
		 for(int i = 0 ; i < GarbagePosition.size() ; i ++ ) 
				System.out.println("   " + GarbagePosition.elementAt(i).x + " ; " + GarbagePosition.elementAt(i).y);

	}
	
	static public int getPositionInGarbageList(int x , int y){
		int i = 0 ; 
		boolean ElementFound = false ;
		while ( !ElementFound  && i < GarbagePosition.size() ){
			if (x == GarbagePosition.elementAt(i).x && y == GarbagePosition.elementAt(i).y)
				ElementFound = true ;
			else
			i++ ;
		}
		if(ElementFound)
			return i ;
		else 
		return -1; 
	}
	

}

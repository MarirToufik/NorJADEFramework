package agents;

import java.util.Scanner;

import NorJadeOntology.Add_request;
import NorJadeOntology.Delete_request;
import jade.core.Agent; 
import jade.wrapper.AgentController;
import NorJadeOntology.*;
//import agents.*;

public class SupervisorAgent extends Agent{
	
	public SupervisorAgent(){
	}
	public void setup(){
		System.out.println("The agent Supervisor starts its execution");
		Delete_request delete = new Delete_request("NorJadeOntology.owl");
		Add_request add = new Add_request("NorJadeOntology.owl");
		
		int Choice = 1 ;
		
		while ((Choice == 1) || (Choice == 2) ){
			
		System.out.println("Is the world's map is known ?");
		System.out.println("1 : The World is Known");
		System.out.println("2 : The World is Unknown");

		Scanner SC1 = new Scanner(System.in);
		Choice = SC1.nextInt();
		switch (Choice) {
		case 1 :{
			delete.Simple_Delete("CleaningWorldNorm");
			delete.Simple_Delete("CleaningWorldGoal");
			add.Insert_Norm("CleaningWorldNorm", "ProceduralNorm"); 
			add.Insert_Goal("CleaningWorldGoal", null, "CleaningKnownWorldBehaviour", "CleaningWorld","CleaningWorldNorm"); 
			try{
				agents.CleanerRobot R = new agents.CleanerRobot();
				AgentController AC =this.getContainerController().acceptNewAgent("Robot", R) ;
				AC.start();
				
				}
				catch (Exception any) {
				    any.printStackTrace();  
				}
			break ;
		}
		case 2 :{
			delete.Simple_Delete("CleaningWorldNorm");
			delete.Simple_Delete("CleaningWorldGoal");
			add.Insert_Norm("CleaningWorldNorm", "ProceduralNorm"); 
			add.Insert_Goal("CleaningWorldGoal", null, "CleaningUnknownWorldBehaviour", "CleaningWorld","CleaningWorldNorm"); 
			try{
				agents.CleanerRobot R = new agents.CleanerRobot();
				AgentController AC = this.getContainerController().acceptNewAgent("Robot", R) ;
				AC.start();
				}
				catch (Exception any) {
				    any.printStackTrace();  
				}
			break ;
		}
		default :{
			System.out.println("See you next Time !");
			break ;	
		}

		}


		}



	}

}

package RewardPunishment;

import jade.core.behaviours.*;

public class NotificationDelay extends OneShotBehaviour{
	
	public void action(){
		
		System.out.println("[NorJADE Framework - Punishment] : The agent "+ this.getAgent().getLocalName() + " say:  we are sorry : The notification date is extended");
	}

}

package start;

import java.util.Scanner; 
import java.util.Vector;
import ressources.*;
import jade.core.*;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.wrapper.*;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.core.Runtime;
import jade.util.ExtendedProperties;
import jade.util.leap.Properties;


public class ConferenceManagment {
	
	 private static Vector <Conference> ListOfConferences = new Vector();
	 private static Vector <Paper> PapersProjects = new Vector();
	 private static int TimeUnit;
	 private static int NbrOfFinishedPapers = 0 ;
	 private static int NbrOfAnnouncedConferences = 0 ;
     private static int NbrOfReachedDeadlines = 0 ;
    private static int NbrOfReachedNotificationDate = 0 ;
    private static int NbrOfReviewingReached = 0 ;
	 
	 public ressources.Timer  T ; 
     
	 public ConferenceManagment(int TimeUnit){
		 this.TimeUnit = TimeUnit;
    	 T = new ressources.Timer(TimeUnit);
    	 T.start();
     }
	 
	 public Vector <Paper> getPapersProjects(){
		 return this.PapersProjects;
	 }
	 
	 public Vector <Conference> getListOfConferences(){
		 return this.ListOfConferences;
	 }
     public void addPaperProject(Paper C){
    	 this.PapersProjects.addElement(C);
     }
     
     public Paper getPaperProject(int Id){
    	 Paper C = null ;
    	 int i = 0;
    	 while (i < this.PapersProjects.size() && this.PapersProjects.elementAt(i).getPaperId() != Id)
    		 i++ ;
    	 if (i < this.PapersProjects.size())
    		 C = this.PapersProjects.elementAt(i);
    	 return C; 
     }
     
     public void removePaper(int Id){
    	 int i = 0; 
    	 while (i < this.PapersProjects.size() && this.PapersProjects.elementAt(i).getPaperId() != Id)
    		 i++ ;
    	 if (i < this.PapersProjects.size())
    		 this.PapersProjects.remove(i);
    	 else
    		 System.out.println("The Paper Project with the Id  : " + Id + "  does not exist in the system !");
     }
     
     public void addConference(Conference C){
    	 this.ListOfConferences.addElement(C);
     }
     
     public Conference getConference(int Id){
    	 Conference C = null ;
    	 int i = 0;
    	 while (i < this.ListOfConferences.size() && this.ListOfConferences.elementAt(i).getConferenceID() != Id)
    		 i++ ;
    	 if (i < this.ListOfConferences.size())
    		 C = this.ListOfConferences.elementAt(i);
    	 return C; 
     }
     
     public void removeConference(int Id){
    	 int i = 0; 
    	 while (i < this.ListOfConferences.size() && this.ListOfConferences.elementAt(i).getConferenceID() != Id)
    		 i++ ;
    	 if (i < this.ListOfConferences.size())
    		 this.ListOfConferences.remove(i);
    	 else
    		 System.out.println("The Conference with the Id  : " + Id + "  does not exist in the system !");
     }

     
     public void displayConferences(){
    	 int i = 0;
    	 if (this.ListOfConferences.size() == 0)
    		 System.out.println("The list of conferences is empty");
    	 else{
    	 while (i < this.ListOfConferences.size()){
    		 System.out.println("The conference Id  :  " + this.ListOfConferences.elementAt(i).getConferenceID() + "  Chair is  : " +this.ListOfConferences.elementAt(i).getConferenceChair()+ "  Domaine is : " + this.ListOfConferences.elementAt(i).getDomaine());
    		 i++;
    	   }
    	 }
     }
     
     public void addPaperToConference(int ConferenceId, Paper P){
    	 int i = 0; 
    	 while (i < this.ListOfConferences.size() && this.ListOfConferences.elementAt(i).getConferenceID() != ConferenceId)
    		 i++ ;
    	 if (i < this.ListOfConferences.size())
    		 this.ListOfConferences.elementAt(i).addReceivedPaper(P);
    	 else
    		 System.out.println("The Conference with the Id  : " + ConferenceId + "  does not exist in the system !");
     }
     
     public void addAcceptedPaperToConference(int ConferenceId, Paper P){
    	 int i = 0; 
    	 while (i < this.ListOfConferences.size() && this.ListOfConferences.elementAt(i).getConferenceID() != ConferenceId)
    		 i++ ;
    	 if (i < this.ListOfConferences.size())
    		 this.ListOfConferences.elementAt(i).addAcceptedPaper(P);
    	 else
    		 System.out.println("The Conference with the Id  : " + ConferenceId + "  does not exist in the system !");
     }
     
     public void addRegistredPaperToConference(int ConferenceId, Paper P){
    	 int i = 0; 
    	 while (i < this.ListOfConferences.size() && this.ListOfConferences.elementAt(i).getConferenceID() != ConferenceId)
    		 i++ ;
    	 if (i < this.ListOfConferences.size())
    		 this.ListOfConferences.elementAt(i).addRegisteredPaper(P);
    	 else
    		 System.out.println("The Conference with the Id  : " + ConferenceId + "  does not exist in the system !");
     }
     
     
     public int getTimeUnit(){
    	 return this.TimeUnit;
     }
     
     public int getNbrOfFinishedPapers(){
    	 return this.NbrOfFinishedPapers ;
     }
     
     public synchronized void IncreaseNbrOfFinishedPapers(){
    	 this.NbrOfFinishedPapers ++;
     }
     
     public synchronized void IncreaseNbrOfReviewingReached(){
    	 this.NbrOfReviewingReached ++;
     }
     
   public int getNbrOfAnnouncedConferences(){
	   return this.NbrOfAnnouncedConferences;
   }
     
   public synchronized void IncreaseNbrOfAnnouncedConferences(){
  	 this.NbrOfAnnouncedConferences ++;
   }
   
   public int getNbrOfReachedNotificationDate(){
	   return this.NbrOfReachedNotificationDate;
   }
   
   public int getNbrOfReviewingReached(){
	   return this.NbrOfReviewingReached;
   }


   public synchronized void IncreaseNbrOfReachedNotificationDate(){
	  	 this.NbrOfReachedNotificationDate ++;
	   }

   
   public int getNbrOfReachedDeadlines(){
	   return this.NbrOfReachedDeadlines;
   }
     
   public synchronized void IncreaseNbrOfReachedDeadlines(){
  	 this.NbrOfReachedDeadlines ++;
   }

     
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ConferenceManagment CM = new ConferenceManagment(1000);
		
		
		Vector <Contributor> V1 = new Vector();
		Vector <Contributor> V2 = new Vector();
		Vector <Contributor> V3 = new Vector();
		Vector <Contributor> V4 = new Vector();

		
		V1.add(new Contributor(new String ("Author1"), 10, 15));
		V1.add(new Contributor(new String ("Author2"), 10, 20));
		V1.add(new Contributor(new String ("Author3"), 10, 10));
		
		V2.add(new Contributor(new String ("Author1"), 50, 5));
		V2.add(new Contributor(new String ("Author2"), 40, 16));
		
		V3.add(new Contributor(new String ("Author4"), 10, 21));
		V3.add(new Contributor(new String ("Author2"), 10, 30));
		
		V4.add(new Contributor(new String ("Author4"), 20, 100));


		Paper P10 = new Paper(0, V1, new String ("CommunicatingAuthor1"), new String ("Software Engineering"));
		Paper P20 = new Paper(1, V2, new String ("CommunicatingAuthor1"), new String ("Software Engineering"));
		Paper P30 = new Paper(2, V3, new String ("CommunicatingAuthor2"), new String ("Software Engineering"));
		Paper P40 = new Paper(3, V4, new String ("CommunicatingAuthor2"), new String ("Software Engineering"));

		/*P10.setEstimatedEvaluationWork(10);
		P20.setEstimatedEvaluationWork(15);
		P30.setEstimatedEvaluationWork(20);
		P40.setEstimatedEvaluationWork(10);*/


		Conference C0 =new Conference(new String("Software Engineering"), new String("ConferenceChairMan"), 0);
		
       /* 
        * The first scenario
        *
        **/
        P10.setEstimatedEvaluationWork(1);
		P20.setEstimatedEvaluationWork(1);
		P30.setEstimatedEvaluationWork(2);
		P40.setEstimatedEvaluationWork(1);

        C0.setCFPDate(0);
        C0.setDeadlineDate(10);
        C0.setNotification(100);
        
		
		/*
		 * the second scenario
		 * */
	 /*   P10.setEstimatedEvaluationWork(1);
		P20.setEstimatedEvaluationWork(1);
		P30.setEstimatedEvaluationWork(2);
		P40.setEstimatedEvaluationWork(1);

	    C0.setCFPDate(0);
        C0.setDeadlineDate(1);
        C0.setNotification(100);

		 */
		
		/*
		 * The third Scenario
		 */
		/*
		P10.setEstimatedEvaluationWork(20);
		P20.setEstimatedEvaluationWork(20);
		P30.setEstimatedEvaluationWork(20);
		P40.setEstimatedEvaluationWork(20);

		
		    C0.setCFPDate(0);
	        C0.setDeadlineDate(10);
	        C0.setNotification(13);
	        
         */
       


        
        C0.addToProgramCommittee(new String("Reviewer0"));
        C0.addToProgramCommittee(new String("Reviewer1"));
        C0.addToProgramCommittee(new String("Reviewer2"));
        
		CM.addPaperProject(P10);
		CM.addPaperProject(P20);
		CM.addPaperProject(P30);
		CM.addPaperProject(P40);

		
		
		CM.addConference(C0);



		try{

			String [] args1 ={"-agents"};
			Runtime rt = Runtime.instance();
			/*ProfileImpl p = new ProfileImpl(false);
			p.setParameter("Gui", "true");
			AgentContainer container =rt.createMainContainer(p);*/
			Properties p=new ExtendedProperties();
			p.setProperty("gui","false");
			ProfileImpl pc=new ProfileImpl(p);
			AgentContainer container=rt.createMainContainer(pc);
			
	        agents.Author A1 = new  agents.Author(CM, 20);  
	        agents.Author A2 = new  agents.Author(CM, 50);  
	        agents.Author A3 = new  agents.Author(CM, 30);  
	        agents.Author A4 = new  agents.Author(CM, 40); 
	        
	        agents.CommunicatingAuthor CA1 = new  agents.CommunicatingAuthor(CM, 40);  
	        agents.CommunicatingAuthor CA2 = new  agents.CommunicatingAuthor(CM, 40);  

	        agents.ConferenceChair CC1 = new  agents.ConferenceChair(CM, 40); 
            /*
             * for third scenario
             */
	        agents.Reviewer R0 = new  agents.Reviewer(CM, 1); 
	        agents.Reviewer R1 = new  agents.Reviewer(CM, 2); 
	        agents.Reviewer R2 = new  agents.Reviewer(CM, 1);  

	        /*
	         agents.Reviewer R0 = new  agents.Reviewer(CM, 10); 
	        agents.Reviewer R1 = new  agents.Reviewer(CM, 5); 
	        agents.Reviewer R2 = new  agents.Reviewer(CM, 10);  

	         */

			AgentController AC1 = container.acceptNewAgent("Author1", A1);
			AgentController AC2 = container.acceptNewAgent("Author2", A2);
			AgentController AC3 = container.acceptNewAgent("Author3", A3);
			AgentController AC4 = container.acceptNewAgent("Author4", A4);
			
			AgentController AC5 = container.acceptNewAgent("CommunicatingAuthor1", CA1);
			AgentController AC6 = container.acceptNewAgent("CommunicatingAuthor2", CA2);
			
			AgentController AC7 = container.acceptNewAgent("ConferenceChairMan", CC1);
			
			AgentController AC8 = container.acceptNewAgent("Reviewer0", R0);
			AgentController AC9 = container.acceptNewAgent("Reviewer1", R1);
			AgentController AC10 = container.acceptNewAgent("Reviewer2", R2);
						
	              AC1.start();
	              AC2.start();
	              AC3.start();
	              AC4.start();
	              AC5.start();
	              AC6.start();
	              AC7.start();
	              AC8.start();
	              AC9.start();
	              AC10.start();
			}
			catch (Exception any) {
			    any.printStackTrace();
			    
			}

	}

}


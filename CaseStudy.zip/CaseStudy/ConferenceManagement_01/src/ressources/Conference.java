package ressources;

import java.util.Vector;
import java.io.Serializable;

public class Conference implements Serializable {
	
	private String Domaine; 
	private String ConferenceChair;
	private Vector <String> ProgramCommittee  = new Vector();
	private Vector <Paper> ReceivedPaper = new Vector();
	private Vector <Paper> AcceptedPaper  = new Vector(); 
	private Vector <Paper> RegisteredPaper  = new Vector();
	private Vector <String> RegistredAutors  = new Vector();
	private boolean Announced ;
	private boolean CloseSubmission ;
	private boolean DeadlineReached ;
	private boolean NotificationReached ;
	private boolean DispatchingReached;
	private boolean ReviewingReached ;
	
	private int ReceivedNotification = 0 ;
	

	private int ConferenceID;
	
	private int CFPDate;
	private int DeadlineDate;
	private int Notification;
	private int EarlyRegistrationDate;
	private int LateRegistrationDate;
	private int ExtendedDedline;
	
	private int EarlyRegistrationFee;
	private int LateRegistrationFee;
	
	private int NbrReviewing ; 
	
	
	public Conference(String Domaine, String ConferenceChair, int ConferenceID){
		
		this.Domaine = Domaine ;
		this.ConferenceChair = ConferenceChair;
		this.ConferenceID = ConferenceID;
		this.Announced = false ;
		this.CloseSubmission =  false ;
		this.DeadlineReached = false ;
		this.NotificationReached = false;
		this.DispatchingReached= false;
		this.ReviewingReached = false ;
		this.NbrReviewing = 2 ;
	}
	
	public int getReceivedNotification(){
		return this.ReceivedNotification ;
	}
	
	public void setReceivedNotification(int X){
		 this.ReceivedNotification = X ;
	}

	
	public int getNbrReviewing(){
		return this.NbrReviewing ;
	}
	
	public void setNbrReviewing(int t){
		 this.NbrReviewing = t ;
	}

	
	public boolean getAnnounced(){
		return this.Announced ;
	}
	
	public void setAnnounced(boolean t){
		 this.Announced = t ;
	}
	
	public boolean getDeadlineReached(){
		return this.DeadlineReached ;
	}
	
	public void setDeadlineReached(boolean t){
		 this.DeadlineReached = t ;
	}
	public boolean getNotificationReached(){
		return this.NotificationReached ;
	}
	
	public void setNotificationReached(boolean t){
		 this.NotificationReached = t ;
	}
	
	
	public boolean getDispatchingReached(){
		return this.DispatchingReached ;
	}
	
	public void setDispatchingReached(boolean t){
		 this.DispatchingReached = t ;
	}

	
	public boolean getReviewingReached(){
		return this.ReviewingReached ;
	}
	
	public void setReviewingReached(boolean t){
		 this.ReviewingReached = t ;
	}

	
	
	
	public boolean getCloseSubmission(){
		return this.CloseSubmission ;
	}
	
	public void setCloseSubmission(boolean t){
		 this.CloseSubmission = t ;
	}


	
	public void setDomaine(String Domaine){
		this.Domaine = Domaine;
	}
	
	public String getDomaine(){
		return this.Domaine;
	}
	
	public void setConferenceChair(String ConferenceChair){
		this.ConferenceChair = ConferenceChair;
	}
	
	public String getConferenceChair(){
		return this.ConferenceChair;
	}
	
	public void addToProgramCommittee(String Reviewer){
		this.ProgramCommittee.addElement(Reviewer);
	}
	
	public int indexInProgramCommittee(String Reviewer){
		int i = 0;
		
		while (i < this.ProgramCommittee.size() && ! this.ProgramCommittee.elementAt(i).equals(Reviewer))
			i++;
		
		if (i == this.ProgramCommittee.size())
			i = -1;
		
		return i;
	}
	
	public void removeFromProgramCommittee(String Reviewer){
		
		if (this.indexInProgramCommittee(Reviewer) != -1)
			this.ProgramCommittee.remove(this.indexInProgramCommittee(Reviewer));
		
		else
  		  System.out.println("  We can not remove the agent  :  " + Reviewer + " from the program committee of Cconference" + this.ConferenceID + "  because it is not a reviewer");
	}
	
	public Vector <String> getProgramCommittee(){
		return this.ProgramCommittee;
	}
	
	public void addReceivedPaper(Paper P){
		this.ReceivedPaper.addElement(P);
		System.out.println("+++** The Paper :  " + P.getPaperId() + "  is added to the conference  :" + this.ConferenceID);

	}
	
	public Vector <Paper> getReceivedPaper(){
		return this.ReceivedPaper;
	}
	
	public void addAcceptedPaper(Paper P){
		this.AcceptedPaper.addElement(P);
	}
	
	public void addRegisteredPaper(Paper P){
		this.RegisteredPaper.addElement(P);
		
	}
	
    public void addRegisteredAuthor(String Author){
    	this.RegistredAutors.addElement(Author);
    }
   public Vector <Paper> UnregisteredPapers(){
	   Vector <Paper> unregistredPapers = new Vector();
	   
	   for (int i = 0; i < this.AcceptedPaper.size(); i++) {
		   if (! this.RegisteredPaper.contains(this.AcceptedPaper.elementAt(i))) 
			   unregistredPapers.addElement(this.AcceptedPaper.elementAt(i));
		   }
	   
	   return unregistredPapers;
   }

   
   public void setConferenceID(int Id){
	   this.ConferenceID = Id;
   }
   
   public int getConferenceID(){
	   return this.ConferenceID;
   }
   
    
 public void setCFPDate(int Date){
	 this.CFPDate = Date;
 }
 
 public int getCFPDate(){
	 return this.CFPDate;
 }
 
 public void setDeadlineDate(int Date){
	 this.DeadlineDate = Date;
 }
 
 public int getDeadlineDate(){
	 return this.DeadlineDate;
 }

 public void setNotification(int Date){
	 this.Notification = Date;
 }
 
 public int getNotification(){
	 return this.Notification;
 }

 public void setEarlyRegistrationDate(int Date){
	 this.EarlyRegistrationDate = Date;
 }
 
 public int getEarlyRegistrationDate(){
	 return this.EarlyRegistrationDate;
 }

 public void setLateRegistrationDate(int Date){
	 this.LateRegistrationDate = Date;
 }
 
 public int getLateRegistrationDate(){
	 return this.LateRegistrationDate;
 }

 public void setExtendedDedline(int Date){
	 this.ExtendedDedline = Date;
 }
 
 public int getExtendedDedline(){
	 return this.ExtendedDedline;
 }
 
 public void setEarlyRegistrationFee(int price){
	 this.EarlyRegistrationFee = price;
 }
 
 public int getEarlyRegistrationFee(){
	 return this.EarlyRegistrationFee ;
 }
 
 public void setLateRegistrationFee(int price){
	 this.LateRegistrationFee = price;
 }
 
 public int getLateRegistrationFee(){
	 return this.LateRegistrationFee ;
 }
public void DisplayPapers(int TypeOfPapers){
	//int i = 0 ;
	switch (TypeOfPapers){
	case 0: {
		System.out.println("We will display the list of received papers in the conference " + this.ConferenceID);
		for(int i = 0; i < this.ReceivedPaper.size(); i++)
			System.out.println("   The paper :  " + this.ReceivedPaper.elementAt(i).getPaperId());
		
		break;
	}
	case 1: {
		System.out.println("We will display the list of accepted papers in the conference " + this.ConferenceID);
		for(int i = 0; i < this.AcceptedPaper.size(); i++)
			System.out.println("   The paper :  " + this.AcceptedPaper.elementAt(i).getPaperId());

		
		break;
	}
	case 2: {
		System.out.println("We will display the list of registred papers in the conference " + this.ConferenceID);
		for(int i = 0; i < this.RegisteredPaper.size(); i++)
			System.out.println("   The paper :  " + this.RegisteredPaper.elementAt(i).getPaperId());

		
		break;
	}
	case 3: {
		Vector <Paper> unregistred = new Vector();
		unregistred = this.UnregisteredPapers();
		System.out.println("We will display the list of unregistred papers in the conference " + this.ConferenceID);
		for(int i = 0; i < unregistred.size(); i++)
			System.out.println("   The paper :  " + unregistred.elementAt(i).getPaperId());

		
		break;
	}
	}
}


 public Paper getPaper(int Id, int TypeOfPapers){
	int i = 0 ;
	 Paper P = null ; 
	switch (TypeOfPapers){
	case 0: {
	     while (i < this.ReceivedPaper.size() && this.ReceivedPaper.elementAt(i).getPaperId() != Id)
	    	 i++; 
	     if (i < this.ReceivedPaper.size())
	    	 P = this.ReceivedPaper.elementAt(i);
		break;
	}
	case 1: {
		while (i < this.AcceptedPaper.size() && this.AcceptedPaper.elementAt(i).getPaperId() != Id)
	    	 i++; 
	     if (i < this.AcceptedPaper.size())
	    	 P = this.AcceptedPaper.elementAt(i);
		
		break;
	}
	case 2: {
		while (i < this.RegisteredPaper.size() && this.RegisteredPaper.elementAt(i).getPaperId() != Id)
	    	 i++; 
	     if (i < this.RegisteredPaper.size())
	    	 P = this.RegisteredPaper.elementAt(i);

				break;
	}
	case 3: {
		Vector <Paper> unregistred = new Vector();
		unregistred = this.UnregisteredPapers();
		while (i < unregistred.size() && unregistred.elementAt(i).getPaperId() != Id)
	    	 i++; 
	     if (i < unregistred.size())
	    	 P = unregistred.elementAt(i);

		
		break;
	}
	}
	
	return P;
}

 
 public void Acceptation(int Id){
	 if (this.getPaper(Id, 0) != null)
	this.AcceptedPaper.addElement(this.getPaper(Id, 0));
 }
 
 public void Registration(int Id){
	 if (this.getPaper(Id, 1) != null)
	 this.RegisteredPaper.addElement(this.getPaper(Id, 1));
 }
}

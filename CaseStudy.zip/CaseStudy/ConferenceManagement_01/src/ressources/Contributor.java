package ressources;

import java.io.Serializable;

public class Contributor  implements Serializable {
	// This is the name of the agent that contribute in Paper writing
	private String Name;
	// This is the time to finish writing of its parts
	private int Time;
	// This is the portion of work must be done by this contributor
	private int Contribution;
    
	
	public Contributor(String Name, int Time, int Contribution){
		this.Name = Name;
		this.Contribution = Contribution; 
		this.Time = Time;
	}
	
	public String getName(){
		return this.Name;
	}
	public int getTime(){
		return Time;
	}
	public int getContribution(){
		return Contribution;
	}
	
	public void setName(String Name){
     this.Name = Name;
	}
	public void setTime(int Time){
		this.Time= Time;
	}
	public void setContribution(int Contribution){
		this.Contribution= Contribution;
	}
}

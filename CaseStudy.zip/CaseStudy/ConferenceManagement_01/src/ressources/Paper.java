package ressources;

import java.io.Serializable;
import java.util.Vector;

public class Paper implements Serializable{
       private boolean WritePermission; 
       private double CompletenessPaper;
       private int CurrentContributor;
       private String Domaine;
       private int PaperId;
       private Vector <Contributor> Contributors = new Vector(); 
       private String CommunicatingAuthor = new String ();
       private Vector <String> ContributorsFinished = new Vector();
       private int TotalRequestedWork = 0 ;
       private int ConferenceID ;
       private int EstimatedEvaluationWork = 0 ;
       private double FinalDecision = 0.0 ;
       private int ConferenceChairdecision ;
       
       
       private Vector <ReviewingResult> ReviewingResults = new Vector();
       
       public Paper(int PaperId, Vector <Contributor> Contributors, String CommunicatingAuthor, String Domaine){
    	   this.WritePermission = true;
    	   this.CompletenessPaper = 0.0; 
    	   this.CurrentContributor = 0;
    	  
    	   this.Contributors= Contributors; 
    	   this.Domaine = Domaine ;
    	   this.PaperId = PaperId;
    	   this.CommunicatingAuthor = CommunicatingAuthor ;
    	   for(int i = 0; i < Contributors.size(); i ++) {
    		   this.TotalRequestedWork = this.TotalRequestedWork + this.Contributors.elementAt(i).getContribution();
    	   }
       }
       
       public String getCommunicatingAuthor(){
    	   return this.CommunicatingAuthor;
       }

       public void setCommunicatingAuthor(String CommunicatingAuthor){
    	    this.CommunicatingAuthor = CommunicatingAuthor;
       }

       
       public String getDomaine(){
    	   return this.Domaine;
       }
       
       public void setDomaine(String Domaine){
    	    this.Domaine = Domaine;
       }
       
       public int getEstimatedEvaluationWork(){
    	   return this.EstimatedEvaluationWork;
       }
       
       public void setEstimatedEvaluationWork(int EEW){
    	   this.EstimatedEvaluationWork= EEW;
       }
       
       public boolean getWritePermission(){
    	   return this.WritePermission;
       }
       
       public void setWritePermission(boolean WP){
    	   this.WritePermission= WP;
       }
       
       public double getCompletenessPaper(){
    	   return this.CompletenessPaper;
       }
       public void setCompletenessPaper(double CP){
    	   this.CompletenessPaper = CP;
       }
       
       public void UpdateCompletenessPaper(double CP){
    	   this.CompletenessPaper = this.CompletenessPaper + CP ;
       }
       
       public Vector <Contributor> getContributors(){
    	   return this.Contributors ;
       }
       
       public int getTotalRequestedWork(){
    	   return this.TotalRequestedWork ;
       }
      public void addContributor(Contributor C){
    	  this.Contributors.addElement(C);
      }
      
      public int getContributorIndex(String Name){
    	  int i = 0; 
    	  while (i < this.Contributors.size() && !((Contributor)this.Contributors.elementAt(i)).getName().equals(Name))
    			  i++;
    	  
    	  if (i == this.Contributors.size())
    	      i = -1;
    	  return i;
      }
      
      public String getContributorName(int i){
    	  String S = null; 
    	  
    	  if (i >=0 && i < this.Contributors.size())
    		  S = this.Contributors.elementAt(i).getName();
    	  
    	  return S; 
      }
      
      public Contributor getContributor(int i){
    	  Contributor C = null ;
    	  if (i >=0 && i < this.Contributors.size())
    		  C = this.Contributors.elementAt(i);
    	  
    	  return C;
      }
      
      public void removeContributor(String Name){
    	  if (getContributorIndex(Name) != -1)
    	     this.Contributors.remove(getContributorIndex(Name));  
    	  
    	  else 
    	  
    		  System.out.println("  We can not remove the agent  :  " + Name + " from the contributors of the paper " + this.PaperId + "  because it is not a contributor");
                 	  
      }	  
      
      public void setPaperId(int Id){
    	  this.PaperId = Id;
      }
      
      public int getPaperId(){
    	  return this.PaperId;
      }
       
      public void setConferenceID(int ConferenceID){
    	  this.ConferenceID = ConferenceID;
      }
      
      public int getConferenceID(){
    	  return this.ConferenceID;
      }
      

      public void setConferenceChairdecision(int Decision){
    	  this.ConferenceChairdecision = Decision;
      }
      
      public int getConferenceChairdecision(){
    	  return this.ConferenceChairdecision;
      }

      
      public synchronized int LockPaper(){
    	  int i ; 
    	  
    	  if (! this.WritePermission) 
    		i = -1 ;
    	  else
    	  {
    		  i = 1 ;
    		  this.WritePermission = false;
    	  }
    	  
    	  return i;
      }
      
      
      public void unLockPaper(){
    	  this.WritePermission = true; 
      }
      
      public void AddReviewingResults(ReviewingResult R){
    	  
    	//  System.out.println("Je suis la methode AddReviewingResults avec les param�tres : " + R.getPaperId() + "  :: " + R.getReviewer() + " ::  " + R.getEvaluation() + "  ::  " + this.ReviewingResults.size() );

    	  this.ReviewingResults.addElement(R);
    	  
    	 // System.out.println(" Apr�s la m�those AddReviewingResults avec les param�tres : " + R.getPaperId() + "  :: " + R.getReviewer() + " ::  " + R.getEvaluation() + "  ::  " + this.ReviewingResults.size() );

      }
      
    public void setReviewingResultsByReviewer(String Reviewer, int Evaluation){
    	  
    	 // System.out.println("Je suis la methode setReviewingResultsByReviewer avec les param�tres : " + Reviewer + "  :: " + Evaluation + " ::  " + this.ReviewingResults.size() );
    	  int i = 0 ;
    	  
    	  while ((i < this.ReviewingResults.size()) && (! this.ReviewingResults.elementAt(i).getReviewer().equals(Reviewer)))
    		  i ++ ;
    	  
    	  if (i < this.ReviewingResults.size()) {
    		  
        	//  System.out.println("Avant la mod�fication : " + this.ReviewingResults.elementAt(i).getReviewer() + "  :: " + this.ReviewingResults.elementAt(i).getEvaluation() );

    		  this.ReviewingResults.elementAt(i).setEvaluation(Evaluation);
    		  
        	 // System.out.println("Apr�s la mod�fication : " + this.ReviewingResults.elementAt(i).getReviewer() + "  :: " + this.ReviewingResults.elementAt(i).getEvaluation() );

    	  
    	  }
    	  
      }
      
      public double getFinalDeision(){
    	return this.FinalDecision ;  
      }

      public void setFinalDeision(double FinalDecision){
    	 this.FinalDecision = FinalDecision ;  
      }

      public void DisplayReviewingResults(){
    	  for(int i = 0; i < this.ReviewingResults.size(); i++){
    		  
			  System.out.println("****   : " + this.ReviewingResults.elementAt(i).getPaperId() + "  ::  " + this.ReviewingResults.elementAt(i).getReviewer() + "  ::  " + this.ReviewingResults.elementAt(i).getEvaluation());

    		  
    	  }

    	  
      }
 
     
      public double CalculateFinalDeision(){
    	 int j =0 ; 
    	 int D = 0;

    	// System.out.println("************* We will calculate the final decision of the paper : " + this.PaperId);
    	  
    	  for(int i = 0; i < this.ReviewingResults.size(); i++){
    		  if (this.ReviewingResults.elementAt(i).getEvaluation() > -1) {
    			  D = D +this.ReviewingResults.elementAt(i).getEvaluation() ;
    			  j ++ ;
    			//  System.out.println("************ The current value is  : " + D);
    		  }
    			  
    	  }
    	  
    	  if (j > 0) 
    		  this.FinalDecision = (D * 1.0) / (j * 1.0);
    	  else
    		  this.FinalDecision = 0.0;
    	  
		//  System.out.println("************ The Final value is  : " + FinalDecision);

    	  return this.FinalDecision; 
      }
}

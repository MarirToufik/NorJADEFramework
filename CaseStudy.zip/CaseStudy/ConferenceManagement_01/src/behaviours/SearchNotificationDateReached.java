package behaviours;

import agents.ConferenceChair;
import ressources.Conference;
import jade.core.behaviours.*;

public class SearchNotificationDateReached extends Behaviour{

	int i = 0;

	public void action(){
	
		
		if ((((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size() > 0) && (((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getNotification() < ((ConferenceChair)(this.myAgent)).CM.T.getTime()) && (!((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getNotificationReached()
) && (((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getConferenceChair().equals(this.myAgent.getLocalName()))) {
			
			System.out.println("*** The agent  :  " + this.myAgent.getLocalName() + "  will found notification reached of the notification of the conference " + ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getConferenceID());

			Conference C = ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i) ;
			C.setNotificationReached(true);
			if (C.getNbrReviewing() == 0) {
			
			this.myAgent.ReachGoal("SendNotifications");
			//((ConferenceChair)(this.myAgent)).addBehaviour(new SendNotification());
	       
			//System.out.println("***The agent  : " + this.myAgent.getLocalName() + " schedule the behaviour of dispatching papers of the cinference :  " + C.getConferenceID() );
	        ((ConferenceChair)(this.myAgent)).CM.IncreaseNbrOfReachedNotificationDate();
			}
		}
		
     i++ ;
		
     if (i == ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size())
			i = 0;


		
}
	
	public boolean done(){
		
		/*if (((ConferenceChair)(this.myAgent)).CM.getNbrOfReachedNotificationDate() == ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size()) {
			System.out.println("************ Toutes les conferences sont finis ");
		}*/
		return ((ConferenceChair)(this.myAgent)).CM.getNbrOfReachedNotificationDate() == ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size(); 
	}
}

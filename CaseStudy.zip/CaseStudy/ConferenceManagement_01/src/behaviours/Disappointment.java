package behaviours;

import jade.core.behaviours.OneShotBehaviour;
import NorJadeAspects.ListOfAgents;

public class Disappointment extends OneShotBehaviour{
	
	public void action(){
		System.out.println("*** I am the agent  :  " + this.myAgent.getLocalName() + "  I am Disappointing !");

	}

}

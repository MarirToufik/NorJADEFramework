package behaviours;

import agents.ConferenceChair;
import agents.Reviewer;
import ressources.Conference;
import ressources.ReviewingResult;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class ReceivingResult extends CyclicBehaviour {
	
	public void action(){
		
		MessageTemplate modele1 = MessageTemplate.MatchPerformative(ACLMessage.ACCEPT_PROPOSAL);			 
		MessageTemplate modele2 = MessageTemplate.MatchPerformative(ACLMessage.REJECT_PROPOSAL);			 
		MessageTemplate modele = MessageTemplate.or(modele1, modele2) ;
		ACLMessage msg = myAgent.receive(modele);
		//ACLMessage msg = myAgent.receive();
		  if (msg != null) {
			  
				  
			  ReviewingResult Result = null ;
				 
				try{
					Result = (ReviewingResult)msg.getContentObject(); 
				  
				}catch(Exception e){
					
				}
				
				((ConferenceChair)(this.myAgent)).CM.getPaperProject(Result.getPaperId()).setReviewingResultsByReviewer(Result.getReviewer(), Result.getEvaluation());
				((ConferenceChair)(this.myAgent)).CM.getConference(Result.getConferenceId()).getPaper(Result.getPaperId(), 0).setReviewingResultsByReviewer(Result.getReviewer(), Result.getEvaluation());
				int X =  ((ConferenceChair)(this.myAgent)).CM.getConference(Result.getConferenceId()).getNbrReviewing() ;
				((ConferenceChair)(this.myAgent)).CM.getConference(Result.getConferenceId()).setNbrReviewing(X - 1) ;
				System.out.println("***  The agent : "+ this.myAgent.getLocalName() +" received the evaluation " + Result.getEvaluation() + "  as an evaluation of the paper " + Result.getPaperId() + "  from the Reviwer  " + Result.getReviewer() );
				
				double k = ((ConferenceChair)(this.myAgent)).CM.getConference(Result.getConferenceId()).getPaper(Result.getPaperId(), 0).CalculateFinalDeision() ;
				System.out.println("***  The actual evaluation of the paper : "+ Result.getPaperId()+" sent to the conference " + Result.getConferenceId() + "  is  : " + ((ConferenceChair)(this.myAgent)).CM.getConference(Result.getConferenceId()).getPaper(Result.getPaperId(), 0).getFinalDeision());

				//((CommunicatingAuthor)(this.myAgent)).AddListOfReceivedCFP(C.getConferenceID());
			  }
		 // }
		  else {
		    block();
		  }

		
	}

}

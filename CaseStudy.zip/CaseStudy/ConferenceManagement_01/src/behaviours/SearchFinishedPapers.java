package behaviours;

import agents.Author;
import agents.CommunicatingAuthor;
import jade.core.behaviours.*;
import ressources.*;

public class SearchFinishedPapers extends Behaviour{
	
	int i = 0; 
	int j = 0;
	double completeness = 99.0 ;
	public void action(){
		//System.out.println("*** The agent  :" +this.myAgent.getLocalName()+ " will start its behaviour SearchFinishedPapers");
		if ((((CommunicatingAuthor)(this.myAgent)).CM.getPapersProjects().size() > 0 ) 	&& (!((CommunicatingAuthor)(this.myAgent)).ListOfFinishedPapers.contains(((CommunicatingAuthor)(this.myAgent)).CM.getPapersProjects().elementAt(i).getPaperId())) 
				&& (((CommunicatingAuthor)(this.myAgent)).CM.getPapersProjects().elementAt(i).getCommunicatingAuthor().equals(this.myAgent.getLocalName())) && (((CommunicatingAuthor)(this.myAgent)).CM.getPapersProjects().elementAt(i).getCompletenessPaper() > this.completeness) && (((CommunicatingAuthor)(this.myAgent)).CM.getPapersProjects().elementAt(i).getWritePermission())) 
		      {
				//System.out.println("*** The agent  :" +this.myAgent.getLocalName()+ " Condition 4");
		    	 ((CommunicatingAuthor)(this.myAgent)).CM.IncreaseNbrOfFinishedPapers(); ;
			     System.out.println("*** The agent  :  " +this.myAgent.getLocalName()+ " found a finished paper");
			     Paper P = ((CommunicatingAuthor)(this.myAgent)).CM.getPapersProjects().elementAt(i);
			//((CommunicatingAuthor)(this.myAgent)).CM.getPapersProjects().remove(i);
			     ((CommunicatingAuthor)(this.myAgent)).AddListOfFinishedPapers(P.getPaperId());
			     ((CommunicatingAuthor)(this.myAgent)).addBehaviour(new SubmittingPaper(P));
				}
		i++; 
		//j++; 
		if (i == ((CommunicatingAuthor)(this.myAgent)).CM.getPapersProjects().size()) 
			i = 0;		
		
	}
	
	public  boolean done(){
   	
		return ((CommunicatingAuthor)(this.myAgent)).CM.getNbrOfFinishedPapers() == ((CommunicatingAuthor)(this.myAgent)).CM.getPapersProjects().size();
		//return j == 5000 ;
	}

}

package behaviours;

import agents.CommunicatingAuthor;
import ressources.Paper;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class ReceivingNotification extends Behaviour{
	 private boolean NotificationReceived = false ;
	
	public void action(){
	
		MessageTemplate modele1 = MessageTemplate.MatchPerformative(ACLMessage.ACCEPT_PROPOSAL);			 
		MessageTemplate modele2 = MessageTemplate.MatchPerformative(ACLMessage.REJECT_PROPOSAL);			 
		MessageTemplate modele = MessageTemplate.or(modele1, modele2) ;
		ACLMessage msg = myAgent.receive(modele);
		  if (msg != null) {
			  
				  
			  Paper ThePaper = null ;
				 
				try{
					ThePaper = (Paper)msg.getContentObject(); 
				  
				}catch(Exception e){
					
				}
				
				System.out.println("***  The agent : "+ this.myAgent.getLocalName() +" received the notification of the paper  " + ThePaper.getPaperId() + "  ( " + ThePaper.getConferenceChairdecision() + "  )  " );
                 this.NotificationReceived = true ;
				//((CommunicatingAuthor)(this.myAgent)).AddListOfReceivedCFP(C.getConferenceID());
			  
		       if (msg.getPerformative() == ACLMessage.ACCEPT_PROPOSAL) 
		    	   this.myAgent.addBehaviour(new Exciting());
		       else
		    	   this.myAgent.addBehaviour(new Disappointment());
		       
		       this.myAgent.addBehaviour(new InformAuthorsByNotification(ThePaper));
		       }
		 // }
		  else {
		    block();
		  }

	}
	
	public boolean done(){
		return this.NotificationReceived ;
	}

}

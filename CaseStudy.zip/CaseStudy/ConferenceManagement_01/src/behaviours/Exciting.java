package behaviours;

import NorJadeAspects.ListOfAgents;
import jade.core.behaviours.OneShotBehaviour;
public class Exciting extends OneShotBehaviour{
	
	public void action(){
		System.out.println("*** I am the agent  :  " + this.myAgent.getLocalName() + "  I am Exciting !");

	}

}

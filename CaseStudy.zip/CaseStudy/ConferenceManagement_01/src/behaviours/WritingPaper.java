package behaviours;

import jade.core.behaviours.*;
import agents.Author;
import agents.CommunicatingAuthor;
public class WritingPaper extends Behaviour {
	
	int i = 0;
	int j = 0;

	public void action(){
	
		//	System.out.println("*** The agent : " + this.myAgent.getLocalName() + " started the behavior Writing Paper");
      
		if (((Author)(this.myAgent)).ListOfInterestedPapers.size() > 0){
			if (! ((Author)(this.myAgent)).ListOfCompletedPapers.contains(((Author)(this.myAgent)).ListOfInterestedPapers.elementAt(i)) ) {
		      // System.out.println("*** The agent : " + this.myAgent.getLocalName() + " found uncomplated paper  : " + ((Author)(this.myAgent)).ListOfInterestedPapers.elementAt(i).intValue());
    	          if ( ((Author)(this.myAgent)).CM.getPaperProject(((Author)(this.myAgent)).ListOfInterestedPapers.elementAt(i)).LockPaper() != -1){
    	        	  behaviours.PaperRedaction Redaction = new behaviours.PaperRedaction();
    	        	  Redaction.setPaper(((Author)(this.myAgent)).CM.getPaperProject(((Author)(this.myAgent)).ListOfInterestedPapers.elementAt(i)));
    	        	  this.myAgent.addBehaviour(Redaction);
    	          }
    	          else{
  	         	//	System.out.println("*** The agent : " + this.myAgent.getLocalName() + " can not locked the paper : " + ((Author)(this.myAgent)).CM.getPaperProject(((Author)(this.myAgent)).ListOfInterestedPapers.elementAt(i)).getPaperId());                   
    	          }
       }
    	          
    	else{
    	
       	//	System.out.println("*** The agent : " + this.myAgent.getLocalName() + " Remark that the paper : " + ((Author)(this.myAgent)).CM.getPaperProject(((Author)(this.myAgent)).ListOfInterestedPapers.elementAt(i)).getPaperId() + "   is already completed");                   
    		
    	}
			i++; 
		    j++;

		}
       
               if (i == ((Author)(this.myAgent)).ListOfInterestedPapers.size()) 
        	i = 0;
		
	//	while (i < ((Author)(this.myAgent)).CM.getPapersProjects().size())
		
	}
	
	public boolean done(){
	   	 return ((Author)(this.myAgent)).CM.getNbrOfFinishedPapers() == ((Author)(this.myAgent)).CM.getPapersProjects().size();
		//return j == 2000 ;
		//return 		((Author)(this.myAgent)).CM.getPapersProjects().size() == 0 ;

	}

}

package behaviours;

import jade.core.AID;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import ressources.*;

import java.io.IOException;

import agents.*;

public class SubmittingPaper extends Behaviour{
	public Paper P ;
	private boolean Isdone = false ;
	int i = 0 ;
	SubmittingPaper(Paper P){
		this.P = P ;
	}
	
	public void action(){
	//	System.out.println("++++ The agent :  " + this.myAgent.getLocalName() + "  Attempt to send the  paper" + P.getPaperId());
		
		if ((((CommunicatingAuthor)this.myAgent).ListOfReceivedCFP.size() > 0) && (((CommunicatingAuthor)this.myAgent).CM.getConference(((CommunicatingAuthor)this.myAgent).ListOfReceivedCFP.elementAt(i)).getDomaine().equals(P.getDomaine())
)) {
			ACLMessage message = new ACLMessage(ACLMessage.PROPOSE);
			message.setSender(this.myAgent.getAID());
            P.setConferenceID(((CommunicatingAuthor)this.myAgent).ListOfReceivedCFP.elementAt(i));
			try {message.setContentObject(P);
			
			}catch(IOException ie){
				ie.printStackTrace();}
           String S =((CommunicatingAuthor)this.myAgent).CM.getConference(((CommunicatingAuthor)this.myAgent).ListOfReceivedCFP.elementAt(i)).getConferenceChair();
           message.addReceiver(new AID(S, AID.ISLOCALNAME));
			((CommunicatingAuthor)this.myAgent).AddListOfSentPapers(P.getPaperId());
			
			this.myAgent.send(message);
			Isdone = true;
			this.myAgent.addBehaviour(new ReceivingNotification());
			System.out.println("++++ The agent :  " + this.myAgent.getLocalName() + "  send the paper" + P.getPaperId() + "to the onference : " + P.getConferenceID());

		}
		if (((CommunicatingAuthor)this.myAgent).ListOfReceivedCFP.size() != 0)
	     	i = (i + 1) %  ((CommunicatingAuthor)this.myAgent).ListOfReceivedCFP.size() ;
		else 
			i = 0;
		/*if (i >= ((CommunicatingAuthor)this.myAgent).ListOfReceivedCFP.size()) 
			i = 0;*/
			
		
	}

	public boolean done(){
		return Isdone;
	}
}

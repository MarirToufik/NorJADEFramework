package behaviours;

import agents.ConferenceChair;
import jade.core.behaviours.*;
import ressources.Conference;

public class ReviewingDateReached extends Behaviour{
	int i = 0;

	public void action(){
	
		
		if ((((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size() > 0) && ((((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getNotification() - 2 ) < ((ConferenceChair)(this.myAgent)).CM.T.getTime()) && (!((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getReviewingReached()
) && (((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i).getConferenceChair().equals(this.myAgent.getLocalName()))) {
			

			Conference C = ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(i) ;
			C.setReviewingReached(true);
	       
			//System.out.println("***The agent  : " + this.myAgent.getLocalName() + " schedule the behaviour of dispatching papers of the conference :  " + C.getConferenceID() );
	        ((ConferenceChair)(this.myAgent)).CM.IncreaseNbrOfReviewingReached();

		
		}
		
     i++ ;
		
     if (i == ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size())
			i = 0;
     
	}

	public boolean done(){
		return ((ConferenceChair)(this.myAgent)).CM.getNbrOfReviewingReached() == ((ConferenceChair)(this.myAgent)).CM.getListOfConferences().size(); 
	}

}

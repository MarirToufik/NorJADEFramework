package behaviours;

import jade.core.AID;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;

import java.io.IOException;

import ressources.*;

public class InformAuthorsByNotification extends OneShotBehaviour {
	
	private boolean Isdone = false;
	private Paper ThePaper ;
	public InformAuthorsByNotification(Paper ThePaper){
		this.ThePaper =  ThePaper ;
		
	}
	
	public void action(){
		
		ACLMessage message = new ACLMessage();
		//this.TheConference.getReceivedPaper().elementAt(i).DisplayReviewingResults();
		   message.setPerformative(ACLMessage.INFORM);					
		try {
			message.setContentObject(this.ThePaper);
		}catch(IOException ie){
			ie.printStackTrace();
			
		}
		message.setSender(this.myAgent.getAID());
		for (int i = 0 ; i < ThePaper.getContributors().size(); i++){
		String S = new String(ThePaper.getContributor(i).getName());
		message.addReceiver(new AID(S, AID.ISLOCALNAME));
		}
					
		this.myAgent.send(message);
		
		System.out.println("*** The agent  :  " + this.myAgent.getLocalName() + "  inform the authors of the paper :  " + this.ThePaper.getPaperId() + " by the  final decision  : " + " (  " + ThePaper.getConferenceChairdecision()+ "   ) ");
	}

		
	
	
/*	public boolean done(){
		return this.Isdone ;
	}*/

}

package behaviours;

import jade.core.AID;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;

import java.io.IOException;

import agents.Author;
import agents.ConferenceChair;
import ressources.*;

public class DispatchingPapers extends Behaviour{
	Conference TheConference ;
	int i = 0;
	int j = 0;
	int NbrReviwer ;
	
/*	DispatchingPapers(Conference C){
		this.TheConference = C ;
		this.NbrReviwer = C.getNbrReviewing() ;
		
	}
	*/
	public DispatchingPapers(){
		this.TheConference = (Conference)((ConferenceChair)(this.myAgent)).CM.getListOfConferences().elementAt(0);
		this.NbrReviwer = this.TheConference.getNbrReviewing() ;
		this.TheConference.setNbrReviewing(this.NbrReviwer * this.TheConference.getReceivedPaper().size());
		
	}

	
	public void action(){
		
		if ((i < this.TheConference.getReceivedPaper().size()) && ( this.TheConference.getProgramCommittee().size() > 0)){
			
			ACLMessage message = new ACLMessage(ACLMessage.REQUEST);
			message.setSender(this.myAgent.getAID());
			Paper ThePaper = this.TheConference.getReceivedPaper().elementAt(i);
						
			//System.out.println("++++ The paper :  " + ThePaper.getPaperId() + "  Will be reviwed by  : " );

			
			for (int k = 0 ; k < this.NbrReviwer ; k ++) {
				String S = this.TheConference.getProgramCommittee().elementAt(j);
				
				ReviewingResult R = new ReviewingResult(S, ThePaper.getPaperId(), this.TheConference.getConferenceID());
                ThePaper.AddReviewingResults(R);
                
				message.addReceiver(new AID(S, AID.ISLOCALNAME));
		        j = (j + 1) % this.TheConference.getProgramCommittee().size() ;
			}
			
              try {message.setContentObject(ThePaper);
			
			}catch(IOException ie){
				ie.printStackTrace();}

			this.myAgent.send(message);
			System.out.println("The agent :  " + this.myAgent.getLocalName() + "  send the paper" + ThePaper.getPaperId() + " for reviwing . " );
            i ++ ;
		}
		
	}
	
	public boolean done(){
		boolean DispatchingComplet = false;
		if (i >= this.TheConference.getReceivedPaper().size()){
			this.TheConference.setDispatchingReached(true);
			DispatchingComplet = true ;
		}
		return DispatchingComplet;
	}

}

package behaviours;

import agents.ConferenceChair;
import ressources.Paper;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class ReceivingPaper extends CyclicBehaviour {
	
	public void action(){
		MessageTemplate modele = MessageTemplate.MatchPerformative(ACLMessage.PROPOSE);			 
		ACLMessage msg = myAgent.receive(modele);
		  if (msg != null) {
		    // process the message
			  
			//  if (msg.getPerformative() == ACLMessage.PROPOSE ){
				  Paper P = null ;
				 
				try{
				   P = (Paper)msg.getContentObject(); 
				  
				}catch(Exception e){
					
				}
				System.out.println("+++  The agent : "+ this.myAgent.getLocalName() +" received the Paper " + P.getPaperId() );
				
				((ConferenceChair)(this.myAgent)).CM.getConference(P.getConferenceID()).addReceivedPaper(((ConferenceChair)(this.myAgent)).CM.getPaperProject(P.getPaperId()));
				//((ConferenceChair)(this.myAgent)).AddListOfReceivedCFP(C.getConferenceID());
			  }
		 // }
		  else {
		    block();
		  }

	}

}

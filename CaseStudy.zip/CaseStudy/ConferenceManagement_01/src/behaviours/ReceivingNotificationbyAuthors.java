package behaviours;

import ressources.Paper;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class ReceivingNotificationbyAuthors extends CyclicBehaviour{
	
	public void action(){
		
		MessageTemplate modele = MessageTemplate.MatchPerformative(ACLMessage.INFORM);			 
		ACLMessage msg = myAgent.receive(modele);
		  if (msg != null) {
			  
				  
			  Paper ThePaper = null ;
				 
				try{
					ThePaper = (Paper)msg.getContentObject(); 
				  
				}catch(Exception e){
					
				}
				
				System.out.println("***  The agent : "+ this.myAgent.getLocalName() +" received the notification of the paper  " + ThePaper.getPaperId() + "  ( " + ThePaper.getConferenceChairdecision() + "  )  " );
				//((CommunicatingAuthor)(this.myAgent)).AddListOfReceivedCFP(C.getConferenceID());
			  
		       if (ThePaper.getConferenceChairdecision() == 1) 
		    	   this.myAgent.addBehaviour(new Exciting());
		       else
		    	   this.myAgent.addBehaviour(new Disappointment());
		       
		       }
		 // }
		  else {
		    block();
		  }

	}

}

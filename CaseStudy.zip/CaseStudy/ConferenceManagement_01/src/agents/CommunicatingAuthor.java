package agents;

import java.util.Vector;

import start.ConferenceManagment;
import jade.core.*;
import jade.core.behaviours.Behaviour;
import ressources.*;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.*;
import jade.domain.FIPAException;

public class CommunicatingAuthor extends Agent{
	
	private int productivity ;
	final private int MaxProductivity = 100 ;
	final private int MinProductivity = 5 ;
	
	public Vector <Integer> ListOfFinishedPapers = new Vector(); 
	public Vector <Integer> ListOfSentPapers = new Vector(); 
	public Vector <Integer> ListOfReceivedCFP = new Vector(); 


	
	public ConferenceManagment CM ;
	
	public CommunicatingAuthor(ConferenceManagment CM, int productivity){
		
		this.CM = CM ;
		this.productivity = productivity;
	}


	
	public void setup(){
	// Regustration in DF
		
	    DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName( this.getAID() );
        
        ServiceDescription sd  = new ServiceDescription();
        sd.setType( "CommunicatingAuthor" );
        sd.setName( this.getLocalName() );
        dfd.addServices(sd);
        
        try {  
            DFService.register(this, dfd );  
        }
        catch (FIPAException fe) { 
        	fe.printStackTrace(); }

		//System.out.println("*** The agent :  " + this.getLocalName() + " will start its behaviour");
			this.addBehaviour(new behaviours.SearchFinishedPapers());
			this.addBehaviour(new behaviours.ReceivingCFP());
	}
	
	public void setProductivity(int x){
		this.productivity = x;
	}
	
	public int getProductivity(){
		return this.productivity;
	}
	
	public void IncreasingProductivity(int x){
		if (this.productivity+x <= this.MaxProductivity) 
			this.productivity = this.productivity+x;
		else 
			this.productivity = this.MaxProductivity ; 
	}
	
	public void DecreasingProductivity(int x){
		if (this.productivity-x > this.MinProductivity) 
			this.productivity = this.productivity-x;
		else 
			this.productivity = this.MinProductivity ; 
	}
	
	public void IncreasingProductivity(){
		System.out.println("The agent : " + this.getLocalName() + "  will increase its productivity");
		if (this.productivity+5 <= this.MaxProductivity) 
			this.productivity = this.productivity+5;
		else 
			this.productivity = this.MaxProductivity ;
	}
	
	public void DecreasingProductivity(){
		System.out.println("The agent : " + this.getLocalName() + "  will decrease its productivity");
		if (this.productivity-5 > this.MinProductivity) 
			this.productivity = this.productivity-5;
		else 
			this.productivity = this.MinProductivity ;
	}
	
	public void AddListOfFinishedPapers(int PaperId){
		if (! this.ListOfFinishedPapers.contains(new Integer(PaperId))) { 
			this.ListOfFinishedPapers.addElement(new Integer(PaperId));
			System.out.println("*** agent  :  " + this.getLocalName() + " added The Paper  :  " + PaperId + "   to Finished of the agent :  " + this.getLocalName());
		}
		else
			System.out.println("*** The Paper  :  " + PaperId + "  is already exist in ListOfFinishedPapers");
	}
	
	public void AddListOfSentPapers(int PaperId){
		if (! this.ListOfSentPapers.contains(new Integer(PaperId))) { 
			this.ListOfSentPapers.addElement(new Integer(PaperId));
			System.out.println("*** The Paper  :  " + PaperId + "   is added to sent papers of the agent :  " + this.getLocalName());
		}
		else
			System.out.println("*** The Paper  :  " + PaperId + "  is already exist in ListOfSentPapers");
	}
	
	
	public void AddListOfReceivedCFP(int ConferenceId){
		if (! this.ListOfReceivedCFP.contains(new Integer(ConferenceId))) { 
			this.ListOfReceivedCFP.addElement(new Integer(ConferenceId));
			System.out.println("*** The conference  :  " + ConferenceId + "   is added to received CFP by the agent :  " + this.getLocalName());
		}
		else
			System.out.println("*** The conference  :  " + ConferenceId + "  is already exist in ListOfReceivedCFP");
	}



}

package agents;

import start.ConferenceManagment;

import java.util.Vector;

import behaviours.*;
import jade.core.*;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.*;
import jade.domain.FIPAException;

public class ConferenceChair extends Agent{
	
	private int credibility ;
	final private int MaxCredibility = 100 ;
	final private int MinCredibility = 5 ;

	
	 public static Vector <Integer> ListOfConferencesDeadlineReached = new Vector();
	
	static public ConferenceManagment CM ;
	public ConferenceChair(ConferenceManagment CM, int credibility){
		this.credibility = credibility ;
		
		this.CM = CM ;
	}
	
	
	public  DFAgentDescription[] getAgentDescription(String S){
    	//System.out.println("We will execute the methode of search  : "  );

		DFAgentDescription[] result = null ;
		DFAgentDescription dfd = new DFAgentDescription();
        ServiceDescription sd  = new ServiceDescription();
        sd.setType( S );
        dfd.addServices(sd);
        try {
         result = DFService.search(this, dfd);
        }
        catch (FIPAException fe) { 
        	fe.printStackTrace(); }
        
        return result;

	}
 

	public void setup(){
//		System.out.println("*** The agent   : "+ this.getLocalName() + "  will start its behaviours" );

		// Regustration in DF
		
	    DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName( this.getAID() );
        
        ServiceDescription sd  = new ServiceDescription();
        sd.setType( "ConferenceChair" );
        sd.setName( this.getLocalName() );
        dfd.addServices(sd);
        
        try {  
            DFService.register(this, dfd );  
        }
        catch (FIPAException fe) { 
        	fe.printStackTrace(); }

    	//System.out.println("We will wait  : "  );

        //this.doWait(10000);
        
    	//System.out.println("We will wakeup  : "  );

        
      /*  DFAgentDescription[] result = this.getAgentDescription(new String ("Author")) ;
        
        for(int i = 0; i < result.length; i ++){
        	
        	System.out.println("The first agent service is  : " + result[i].getName().getLocalName() );
        }*/
	//  this.ReachGoal(new String("WritingMySection"));
        this.addBehaviour(new SendingCFP());
        this.addBehaviour(new ReceivingPaper());
        this.addBehaviour(new SearchReachedDeadline()); 
        this.addBehaviour(new ReceivingResult());
        this.addBehaviour(new SearchNotificationDateReached());
        this.addBehaviour(new ReviewingDateReached());
        
       // this.SupressLaw("SubmittingPaperLaw");

		
	}
	
	public void AddListOfConferencesDeadlineReached(int ConferenceId){
		if (! this.ListOfConferencesDeadlineReached.contains(new Integer(ConferenceId))) { 
			this.ListOfConferencesDeadlineReached.addElement(new Integer(ConferenceId));
			System.out.println("*** The agent  :  " + this.getLocalName() + " added The conference  :  " + ConferenceId + "   to reached deadline  ") ;
		}
		else
			System.out.println("*** The Conference  :  " + ConferenceId + "  is already exist in ListOfConferencesDeadlineReached");
	}

	
	public void setcredibility(int x){
		this.credibility = x;
	}
	
	public int getcredibility(){
		return this.credibility;
	}
	
	public void IncreasingCredibility(int x){
		if (this.credibility+x <= this.MaxCredibility) 
			this.credibility = this.credibility+x;
		else 
			this.credibility = this.MaxCredibility ; 
	}
	
	public void DecreasingCredibility(int x){
		if (this.credibility-x > this.MinCredibility) 
			this.credibility = this.credibility-x;
		else 
			this.credibility = this.MinCredibility ; 
	}
	
	public void IncreasingCredibility(){
		System.out.println("The agent : " + this.getLocalName() + "  will increase its credibility");
		if (this.credibility+5 <= this.MaxCredibility) 
			this.credibility = this.credibility+5;
		else 
			this.credibility = this.MaxCredibility ;
	}
	
	public void DecreasingCredibility(){
		System.out.println("The agent : " + this.getLocalName() + "  will decrease its credibility");
		if (this.credibility-5 > this.MinCredibility) 
			this.credibility = this.credibility-5;
		else 
			this.credibility = this.MinCredibility ;
	}


}

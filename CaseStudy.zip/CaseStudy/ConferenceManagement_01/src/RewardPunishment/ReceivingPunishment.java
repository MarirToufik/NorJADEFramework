package RewardPunishment;

import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class ReceivingPunishment extends CyclicBehaviour{
	
	public void action(){
		MessageTemplate modele1 = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);			 
		MessageTemplate modele2 = MessageTemplate.MatchOntology("NorJadeOntology");	
		MessageTemplate modele = MessageTemplate.and(modele1, modele2);
		ACLMessage msg = myAgent.receive(modele);
		  if (msg != null) {
			  Behaviour b = null;
				try{
			  b = (Behaviour)msg.getContentObject();
		      }catch(Exception e){
				
			  }
				System.out.println("[NorJADE Framework] : The agent  :  " + this.getAgent().getLocalName() + " will execute the punishment : " + b.getBehaviourName());
		       this.myAgent.addBehaviour(b);
		  }
		 

	}

}
